#!/bin/bash
set -Eeuo pipefail
work=/workspace/cnot-stream5-red-src
out=/workspace/cnot-stream5-red-results
private=/workspace/cnot-rust-private
mkdir -p "$work" "$out" "$private/native-build" "$private/fixture" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp /workspace/cnot-stream5-red-bundle/source-manifest.json /workspace/cnot-stream5-red-bundle/private-manifest.json /workspace/cnot-stream5-red-bundle/run.sh "$out/"
  tar -czf /workspace/cnot-stream5-red-evidence.tar.gz -C /workspace cnot-stream5-red-results
  sha256sum /workspace/cnot-stream5-red-evidence.tar.gz > /workspace/cnot-stream5-red-evidence.sha256
  exit "$code"
}
trap finish EXIT
tar -xzf /workspace/cnot-stream5-red-bundle/base.tar.gz -C "$work"
cp "$work/integrations/cayleypy_native/multigpubeamsearch/cnot.py" /workspace/cnot-stream5-red-goal-baseline.py
cp -a /workspace/cnot-stream5-red-bundle/overlay/. "$work/"
tar -xzf /workspace/cnot-stream5-red-bundle/native-prepared.tar.gz -C "$private/native-build"
tar -xzf /workspace/cnot-stream5-red-bundle/fixture.tar.gz -C "$private/fixture"
verify_source() {
  python - "$work" /workspace/cnot-stream5-red-bundle/source-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
  python - "$private" /workspace/cnot-stream5-red-bundle/private-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
actual=hashlib.sha256((p/'native-build/native/src/run_config/execution/mgbs_scorer.rs').read_bytes().replace(b'\r\n',b'\n')).hexdigest()
assert actual==m['bridge_sha256'],(actual,m['bridge_sha256'])
print('verified private bridge',actual)
PY
}
verify_source > "$out/source-before.txt"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 TORCH_EXTENSIONS_DIR=/workspace/torch-extensions
export REQUIRE_RUST_CNOT=1 CMAKE_BUILD_PARALLEL_LEVEL=4 CUDA_PATH=/usr/local/cuda CUDACXX=/usr/local/cuda/bin/nvcc
export CNOT103_CUDA_ARCHITECTURES=86 CNOT103_REQUIRE_CUDA=1 LIBTORCH_USE_PYTORCH=1 PYTHON="$(command -v python)"
export LD_LIBRARY_PATH="$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv > "$out/gpus.csv"
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count());assert torch.cuda.device_count()>=2' > "$out/software.txt"
echo BOOTSTRAP > "$out/status.txt"
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
if ! command -v cargo >/dev/null; then
  curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
  sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
{ rustc --version; cargo --version; nvcc --version; g++ --version | head -n 1; } >> "$out/software.txt"
cd "$work"
echo RUST_TESTS >> "$out/status.txt"
timeout 600 cargo test --workspace --locked > "$out/rust-tests.log" 2>&1
echo RUST_EXTENSION >> "$out/status.txt"
timeout 300 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo CNOT_STREAM5_RED >> "$out/status.txt"
set +e
timeout 180 python -m pytest -q integrations/cayleypy_native/tests/test_cnot_stream5_rust.py -x --tb=short --basetemp /workspace/tmp/cnot-stream5-red -p no:cacheprovider > "$out/cnot-stream5-red.log" 2>&1
code=$?
set -e
if [ "$code" -ne 1 ] || ! grep -q 'Rust Stream 5 ownership is unavailable' "$out/cnot-stream5-red.log"; then
  echo "unexpected red test result: $code" >&2
  exit 1
fi
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo RED_CONFIRMED >> "$out/status.txt"
echo COMPLETE >> "$out/status.txt"
