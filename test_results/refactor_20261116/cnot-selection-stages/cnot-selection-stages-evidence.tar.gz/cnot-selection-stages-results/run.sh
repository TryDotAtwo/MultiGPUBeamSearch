#!/bin/bash
set -Eeuo pipefail
work=/workspace/cnot-selection-stages-src
out=/workspace/cnot-selection-stages-results
private=/workspace/cnot-rust-private
mkdir -p "$work" "$out" "$private/native-build" "$private/fixture" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp /workspace/cnot-selection-stages-bundle/source-manifest.json /workspace/cnot-selection-stages-bundle/private-manifest.json /workspace/cnot-selection-stages-bundle/run.sh "$out/"
  tar -czf /workspace/cnot-selection-stages-evidence.tar.gz -C /workspace cnot-selection-stages-results
  sha256sum /workspace/cnot-selection-stages-evidence.tar.gz > /workspace/cnot-selection-stages-evidence.sha256
  exit "$code"
}
trap finish EXIT
tar -xzf /workspace/cnot-selection-stages-bundle/base.tar.gz -C "$work"
cp "$work/integrations/cayleypy_native/multigpubeamsearch/cnot.py" /workspace/cnot-selection-stages-goal-baseline.py
cp -a /workspace/cnot-selection-stages-bundle/overlay/. "$work/"
tar -xzf /workspace/cnot-selection-stages-bundle/native-prepared.tar.gz -C "$private/native-build"
tar -xzf /workspace/cnot-selection-stages-bundle/fixture.tar.gz -C "$private/fixture"
verify_source() {
  python - "$work" /workspace/cnot-selection-stages-bundle/source-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
  python - "$private" /workspace/cnot-selection-stages-bundle/private-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
actual=hashlib.sha256((p/'native-build/native/src/run_config/execution/mgbs_scorer.rs').read_bytes().replace(b'\r\n',b'\n')).hexdigest()
assert actual==m['bridge_sha256'],(actual,m['bridge_sha256'])
print('verified private bridge',actual)
PY
}
verify_source > "$out/source-before.txt"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 TORCH_EXTENSIONS_DIR=/workspace/torch-extensions
export REQUIRE_RUST_CNOT=1 CMAKE_BUILD_PARALLEL_LEVEL=4 CUDA_PATH=/usr/local/cuda CUDACXX=/usr/local/cuda/bin/nvcc
export CNOT103_CUDA_ARCHITECTURES=86 CNOT103_REQUIRE_CUDA=1 LIBTORCH_USE_PYTORCH=1 PYTHON="$(command -v python)"
export LD_LIBRARY_PATH="$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv > "$out/gpus.csv"
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count());assert torch.cuda.device_count()>=2' > "$out/software.txt"
echo BOOTSTRAP > "$out/status.txt"
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
if ! command -v cargo >/dev/null; then
  curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
  sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
{ rustc --version; cargo --version; nvcc --version; g++ --version | head -n 1; } >> "$out/software.txt"
cd "$work"
echo RUST_TESTS >> "$out/status.txt"
timeout 600 cargo test --workspace --locked > "$out/rust-tests.log" 2>&1
echo RUST_EXTENSION >> "$out/status.txt"
timeout 300 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo CNOT_CPU >> "$out/status.txt"
timeout 400 python -m pytest -q integrations/cayleypy_native/tests/test_cnot_search.py integrations/cayleypy_native/tests/test_cnot_rust_controller.py integrations/cayleypy_native/tests/test_cnot_collective_goal.py integrations/cayleypy_native/tests/test_cnot_rust_selection.py --tb=short --basetemp /workspace/tmp/cnot -p no:cacheprovider > "$out/cnot-cpu.log" 2>&1
echo CNOT_CUDA_ATEN >> "$out/status.txt"
timeout 600 python -m pytest -q integrations/cayleypy_native/tests/test_cnot_frontier_cuda.py integrations/cayleypy_native/tests/test_cnot_expand_cuda.py integrations/cayleypy_native/tests/test_cnot_distinct_cuda.py integrations/cayleypy_native/tests/test_cnot_goal_cuda.py integrations/cayleypy_native/tests/test_cnot_radix_cuda.py integrations/cayleypy_native/tests/test_cnot_exchange_cuda.py integrations/cayleypy_native/tests/test_cnot_selection_stages_cuda.py --tb=short --basetemp /workspace/tmp/cnot-cuda -p no:cacheprovider > "$out/cnot-cuda.log" 2>&1
echo GPU_ONE >> "$out/status.txt"
timeout 600 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-1" python integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-1.log" 2>&1
echo GPU_TWO >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-2.log" 2>&1
echo RADIX_NCCL >> "$out/status.txt"
timeout 400 torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_selection_nccl.py > "$out/radix-nccl.log" 2>&1
echo NATIVE_GOAL_NCCL >> "$out/status.txt"
timeout 400 torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_goal_native_nccl.py > "$out/goal-native-nccl.log" 2>&1
echo LEGACY_GOAL_NCCL >> "$out/status.txt"
timeout 600 env CNOT_GOAL_BASELINE=/workspace/cnot-selection-stages-goal-baseline.py CNOT_GOAL_EVIDENCE="$out/receipts/goal-legacy" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_goal_distributed.py > "$out/goal-legacy-nccl.log" 2>&1
echo SCORER_BUILD >> "$out/status.txt"
cd "$private/native-build/native"
timeout 600 cargo build --locked --release --lib --features cuda > "$out/scorer-build.log" 2>&1
export MGBS_TQP_LIBRARY="$CARGO_TARGET_DIR/release/libcnot103_native.so" MGBS_TQP_MANIFEST="$private/fixture/search-qhat.json"
sha256sum "$MGBS_TQP_LIBRARY" > "$out/scorer-library-sha256.txt"
cd "$work"
echo CHECKPOINT_ONE >> "$out/status.txt"
timeout 300 env CNOT_RUST_EVIDENCE="$out/receipts/checkpoint-1" python integrations/cayleypy_native/tests/cnot_rust_checkpoint.py > "$out/checkpoint-1.log" 2>&1
echo CHECKPOINT_TWO >> "$out/status.txt"
timeout 400 env CNOT_RUST_EVIDENCE="$out/receipts/checkpoint-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_checkpoint.py > "$out/checkpoint-2.log" 2>&1
echo FULL_PYTHON_SUITE >> "$out/status.txt"
timeout 600 python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/full -p no:cacheprovider > "$out/python-tests.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
