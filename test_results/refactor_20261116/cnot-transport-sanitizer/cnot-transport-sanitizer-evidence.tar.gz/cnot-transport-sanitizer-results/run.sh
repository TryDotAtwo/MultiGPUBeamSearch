#!/bin/bash
set -Eeuo pipefail
work=/workspace/cnot-transport-pass-src
out=/workspace/cnot-transport-sanitizer-results
mkdir -p "$out" /workspace/tmp/sanitizer
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp /workspace/cnot-transport-pass-bundle/source-manifest.json "$out/"
  cp /workspace/cnot-transport-sanitizer.sh "$out/run.sh"
  tar -czf /workspace/cnot-transport-sanitizer-evidence.tar.gz -C /workspace cnot-transport-sanitizer-results
  sha256sum /workspace/cnot-transport-sanitizer-evidence.tar.gz > /workspace/cnot-transport-sanitizer-evidence.sha256
  exit "$code"
}
trap finish EXIT
echo VERIFY_SOURCE > "$out/status.txt"
verify_source() {
  python - "$work" /workspace/cnot-transport-pass-bundle/source-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
export TMPDIR=/workspace/tmp/sanitizer CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests" PYTHONDONTWRITEBYTECODE=1
export TORCH_CUDA_ARCH_LIST=8.6 MAX_JOBS=4 TORCH_EXTENSIONS_DIR=/workspace/torch-extensions
export LD_LIBRARY_PATH="$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
{ nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv; nvidia-smi topo -m; nvcc --version; compute-sanitizer --version; python -c 'import platform,torch;print(platform.platform());print("torch",torch.__version__);print("torch_cuda",torch.version.cuda);print("nccl",torch.cuda.nccl.version())'; } > "$out/software.txt" 2>&1
sha256sum "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so" > "$out/extension-sha256.txt"
cd "$work"
echo MEMCHECK_NCCL >> "$out/status.txt"
timeout 400 torchrun --standalone --nproc-per-node=2 --no-python compute-sanitizer --tool memcheck --error-exitcode 97 --log-file "$out/memcheck-%p.log" "$(command -v python)" integrations/cayleypy_native/tests/cnot_stream5_exchange_nccl.py > "$out/transport.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
