compute-sanitizer --tool racecheck --error-exitcode 99  build/stream4_dirty_merge_257_cuda_tests
