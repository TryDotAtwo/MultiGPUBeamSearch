compute-sanitizer --tool memcheck --error-exitcode 99 --leak-check full build/stream4_dirty_merge_257_cuda_tests
