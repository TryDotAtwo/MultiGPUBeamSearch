# Per Stream Benchmark 2026-05-22

- puzzle_id=1000
- gpu_total_bytes=150109880320
- gpu_free_before_bytes=149557411840
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=1
- weight_dir=/workspace
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=6371424
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=1024
- filter_concurrency=1

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|1024|1|1024|2.0024|511391.0|12273383.6|371933184|190.203|817953792|10356827707323550595|`34006,32650,33802,33717,34007,34163,33206,33850,33332,33735,33276,33717,33300,33182,34166,33155,33400,33184,32568,32052,32437,31315,33030,33533`|402702336|33554432|100663296|100663296|33554432|134217728|49152|

## Status

- status=pass
