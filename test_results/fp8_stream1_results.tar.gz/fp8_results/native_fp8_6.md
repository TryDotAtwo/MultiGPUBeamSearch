# Per Stream Benchmark 2026-05-22

- puzzle_id=1000
- gpu_total_bytes=150111977472
- gpu_free_before_bytes=149559508992
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=1
- weight_dir=/workspace/hopper_offline_qkv_e4m3_v2
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=5781600
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=384
- filter_concurrency=8

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|384|8|3072|4.9157|624941.3|14998590.8|371933184|232.436|2462118912|16604305729294404483|`34070,32746,33898,33813,34039,34259,33302,33914,33396,33831,33404,33813,33428,33310,34262,33251,33592,33312,32792,32116,32549,31491,33158,33725`|1109016576|89653248|268959744|301989888|89653248|358612992|147456|

## Status

- status=pass
