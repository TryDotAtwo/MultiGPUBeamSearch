# Per Stream Benchmark 2026-05-22

- puzzle_id=2
- gpu_total_bytes=150111977472
- gpu_free_before_bytes=149559508992
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=0
- weight_dir=/workspace/hopper_offline_qkv_ffn_e4m3_v1
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=4208736
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=384
- filter_concurrency=8

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|384|8|3072|4.2798|717796.3|17227111.7|371933184|266.972|437322752|9699102263457997699|`3942,1976,4158,4185,4153,4323,4346,4084,4050,4055,4074,4087,4112,4050,4092,4067,4056,4210,4152,4132,4141,4145,4076,4201`|1109016576|89653248|268959744|301989888|89653248|358612992|147456|

## Status

- status=pass
