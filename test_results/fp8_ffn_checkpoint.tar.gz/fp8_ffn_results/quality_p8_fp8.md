# Per Stream Benchmark 2026-05-22

- puzzle_id=8
- gpu_total_bytes=150111977472
- gpu_free_before_bytes=149559508992
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=0
- weight_dir=/workspace/hopper_offline_qkv_ffn_e4m3_v1
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=4208736
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=384
- filter_concurrency=8

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|384|8|3072|4.3014|714188.3|17140520.3|371933184|265.630|747645952|3802820919396885379|`8598,8302,8586,8733,8367,8563,8338,8522,8492,8463,8652,8629,8532,8614,8510,8387,8576,8664,8488,6424,8461,8571,8526,8533`|1109016576|89653248|268959744|301989888|89653248|358612992|147456|

## Status

- status=pass
