#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-owned-domain5-bundle
work=/workspace/cnot-owned-domain5-src
out=/workspace/cnot-owned-domain5-results
mkdir -p "$work" "$out" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$bundle/run.sh" "$out/"
  tar -czf /workspace/cnot-owned-domain5-evidence.tar.gz -C /workspace cnot-owned-domain5-results
  sha256sum /workspace/cnot-owned-domain5-evidence.tar.gz > /workspace/cnot-owned-domain5-evidence.sha256
  exit "$code"
}
trap finish EXIT
tar -xzf "$bundle/base.tar.gz" -C "$work"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-cnot-owned-domain5
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH" LD_LIBRARY_PATH="/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export TORCH_EXTENSIONS_DIR=/workspace/torch-extensions REQUIRE_RUST_CNOT=1
export CUDACXX=/usr/local/cuda/bin/nvcc CUDA_PATH=/usr/local/cuda
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv > "$out/gpus.csv"
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count());assert torch.cuda.device_count()>=2' > "$out/software.txt"
echo BOOTSTRAP > "$out/status.txt"
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
if ! command -v cargo >/dev/null; then
  curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
  sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
rustup component add rustfmt >> "$out/rustup.log" 2>&1
{ rustc --version; cargo --version; nvcc --version; g++ --version | head -n 1; } >> "$out/software.txt"
cd "$work"
echo BASELINE_RED >> "$out/status.txt"
timeout 300 nvcc -std=c++17 -Xcompiler -fPIC -shared -arch=sm_86 -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_STATE_PHYSICAL_BYTES=128 -DBEAM_STATE_ALIGNMENT=16 -DBEAM_MOVE_COUNT=12 cuda/cnot_domain.cu cuda/cnot_unique.cu -o /workspace/baseline-cnot.so > "$out/baseline-build.log" 2>&1
set +e
BEAM_CNOT_OWNED_LIBRARY=/workspace/baseline-cnot.so python "$bundle/overlay/tests/cnot_owned_domain_test.py" > "$out/red.log" 2>&1
code=$?
set -e
if [ "$code" -eq 0 ] || ! grep -q 'undefined symbol: beam_cnot_domain_abi_version' "$out/red.log"; then
  echo "baseline did not fail on the missing owned-domain ABI: $code" >&2
  exit 1
fi
echo RED_CONFIRMED >> "$out/status.txt"
cp -a "$bundle/overlay/." "$work/"
verify_source() {
  python - "$work" "$bundle/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
echo CMAKE_CONFIGURE >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-owned5 -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON -DBEAM_CUDA_ARCHITECTURES=86 -DCMAKE_BUILD_TYPE=Release > "$out/cmake-configure.log" 2>&1
echo CMAKE_BUILD >> "$out/status.txt"
timeout 600 cmake --build /workspace/build-cnot-owned5 --target beam_cnot_owned_domain > "$out/cmake-build.log" 2>&1
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-owned5/libbeam_cnot_owned_domain.so BEAM_TEST_SECOND_GPU=1
sha256sum "$BEAM_CNOT_OWNED_LIBRARY" > "$out/library-sha256.txt"
echo CUDA_DOMAIN >> "$out/status.txt"
timeout 300 python tests/cnot_owned_domain_test.py > "$out/cuda-domain.log" 2>&1
echo MEMCHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full python tests/cnot_owned_domain_test.py > "$out/memcheck.log" 2>&1
echo RACECHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool racecheck --error-exitcode 97 python tests/cnot_owned_domain_test.py > "$out/racecheck.log" 2>&1
echo RUST_WORKSPACE >> "$out/status.txt"
timeout 600 cargo test --workspace --locked > "$out/rust-workspace.log" 2>&1
echo RUST_GPU >> "$out/status.txt"
timeout 300 cargo test --locked -p beam-native-sys --test cnot_owned_domain -- --ignored --nocapture > "$out/rust-gpu.log" 2>&1
echo RUST_FORMAT >> "$out/status.txt"
cargo fmt --all -- --check > "$out/rust-format.log" 2>&1
echo RUST_EXTENSION >> "$out/status.txt"
timeout 300 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo CNOT_REGRESSION >> "$out/status.txt"
timeout 400 python -m pytest -q integrations/cayleypy_native/tests/test_cnot_search.py integrations/cayleypy_native/tests/test_cnot_rust_controller.py integrations/cayleypy_native/tests/test_cnot_rust_exchange.py integrations/cayleypy_native/tests/test_cnot_rust_checked.py --tb=short --basetemp /workspace/tmp/cnot-regression -p no:cacheprovider > "$out/cnot-regression.log" 2>&1
echo GPU_SEARCH_ONE >> "$out/status.txt"
timeout 600 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-1" python integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-1.log" 2>&1
echo GPU_SEARCH_TWO >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-2.log" 2>&1
echo FULL_PYTHON >> "$out/status.txt"
timeout 600 python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/cnot-owned-full -p no:cacheprovider > "$out/python-tests.log" 2>&1
echo CROSS_COMPILE >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-owned5-cross -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON '-DBEAM_CUDA_ARCHITECTURES=75;80;90;120' -DCMAKE_BUILD_TYPE=Release > "$out/cross-configure.log" 2>&1
timeout 900 cmake --build /workspace/build-cnot-owned5-cross --target beam_cnot_owned_domain > "$out/cross-build.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
