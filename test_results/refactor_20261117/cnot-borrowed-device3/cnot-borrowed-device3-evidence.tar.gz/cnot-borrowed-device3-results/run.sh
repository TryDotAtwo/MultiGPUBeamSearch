#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-borrowed-device3-bundle
work=/workspace/cnot-borrowed-device3-src
out=/workspace/cnot-borrowed-device3-results
mkdir -p "$work" "$out" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$bundle/run.sh" "$out/"
  tar -czf /workspace/cnot-borrowed-device3-evidence.tar.gz -C /workspace cnot-borrowed-device3-results
  sha256sum /workspace/cnot-borrowed-device3-evidence.tar.gz > /workspace/cnot-borrowed-device3-evidence.sha256
  exit "$code"
}
trap finish EXIT
tar -xzf "$bundle/base.tar.gz" -C "$work"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-cnot-borrowed-device3
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH" LD_LIBRARY_PATH="/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests:$bundle/overlay/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export TORCH_EXTENSIONS_DIR=/workspace/torch-extensions3 REQUIRE_RUST_CNOT=1
export CUDACXX=/usr/local/cuda/bin/nvcc CUDA_PATH=/usr/local/cuda BEAM_TEST_SECOND_GPU=1
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv > "$out/gpus.csv"
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count());assert torch.cuda.device_count()>=2' > "$out/software.txt"
echo BOOTSTRAP > "$out/status.txt"
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
if ! command -v cargo >/dev/null; then
  curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
  sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
rustup component add rustfmt >> "$out/rustup.log" 2>&1
{ rustc --version; cargo --version; nvcc --version; g++ --version | head -n 1; } >> "$out/software.txt"
cd "$work"
echo OLD_ABI_BUILD >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-device3-old -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON -DBEAM_CUDA_ARCHITECTURES=86 -DCMAKE_BUILD_TYPE=Release > "$out/old-configure.log" 2>&1
timeout 600 cmake --build /workspace/build-cnot-device3-old --target beam_cnot_owned_domain > "$out/old-build.log" 2>&1
export BEAM_CNOT_OLD_LIBRARY=/workspace/build-cnot-device3-old/libbeam_cnot_owned_domain.so
echo BASELINE_RED >> "$out/status.txt"
set +e
BEAM_CNOT_OWNED_LIBRARY="$BEAM_CNOT_OLD_LIBRARY" python "$bundle/overlay/tests/cnot_borrowed_device_test.py" > "$out/red.log" 2>&1
code=$?
set -e
if [ "$code" -eq 0 ] || ! grep -q 'undefined symbol: beam_cnot_domain_device_abi_version' "$out/red.log"; then
  echo "baseline did not fail on missing device extension: $code" >&2
  exit 1
fi
echo RED_CONFIRMED >> "$out/status.txt"
cp -a "$bundle/overlay/." "$work/"
verify_source() {
  python - "$work" "$bundle/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
echo NEW_ABI_BUILD >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-device3-new -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON -DBEAM_CUDA_ARCHITECTURES=86 -DCMAKE_BUILD_TYPE=Release > "$out/new-configure.log" 2>&1
timeout 600 cmake --build /workspace/build-cnot-device3-new --target beam_cnot_owned_domain > "$out/new-build.log" 2>&1
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-device3-new/libbeam_cnot_owned_domain.so
sha256sum "$BEAM_CNOT_OLD_LIBRARY" "$BEAM_CNOT_OWNED_LIBRARY" > "$out/libraries-sha256.txt"
echo DOMAIN_AND_BORROWED_GPU >> "$out/status.txt"
timeout 300 python tests/cnot_owned_domain_test.py > "$out/domain.log" 2>&1
timeout 300 python tests/cnot_borrowed_device_test.py > "$out/borrowed.log" 2>&1
echo MEMCHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full python tests/cnot_borrowed_device_test.py > "$out/memcheck.log" 2>&1
echo NATIVE_MEMCHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full python tests/cnot_owned_domain_test.py > "$out/native-memcheck.log" 2>&1
echo RACECHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool racecheck --error-exitcode 97 python tests/cnot_borrowed_device_test.py > "$out/racecheck.log" 2>&1
echo RUST_WORKSPACE >> "$out/status.txt"
timeout 600 cargo test --workspace --locked > "$out/rust-workspace.log" 2>&1
timeout 300 cargo test --locked -p beam-native-sys --test cnot_owned_domain -- --ignored --nocapture > "$out/rust-domain.log" 2>&1
timeout 300 cargo test --locked -p beam-native-sys --test cnot_borrowed_device -- --ignored --nocapture > "$out/rust-borrowed.log" 2>&1
echo RUST_DEVICE_MEMCHECK >> "$out/status.txt"
rust_test=$(find "$CARGO_TARGET_DIR/debug/deps" -maxdepth 1 -type f -executable -name 'cnot_borrowed_device-*' | head -n 1)
test -n "$rust_test"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full "$rust_test" --ignored --nocapture > "$out/rust-memcheck.log" 2>&1
cargo fmt --all -- --check > "$out/rust-format.log" 2>&1
echo RUST_EXTENSION >> "$out/status.txt"
timeout 300 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo GPU_SEARCH_ONE >> "$out/status.txt"
timeout 600 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-1" python integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-1.log" 2>&1
echo GPU_SEARCH_TWO >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-2.log" 2>&1
echo FULL_PYTHON >> "$out/status.txt"
timeout 600 python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/cnot-device-full -p no:cacheprovider > "$out/python-tests.log" 2>&1
echo CROSS_COMPILE >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-device3-cross -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON '-DBEAM_CUDA_ARCHITECTURES=75;80;90;120' -DCMAKE_BUILD_TYPE=Release > "$out/cross-configure.log" 2>&1
timeout 900 cmake --build /workspace/build-cnot-device3-cross --target beam_cnot_owned_domain > "$out/cross-build.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
