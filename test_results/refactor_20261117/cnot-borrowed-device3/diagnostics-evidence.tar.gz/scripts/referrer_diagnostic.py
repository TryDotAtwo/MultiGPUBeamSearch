from pathlib import Path
import subprocess
import sys

root = Path('D:/100XH100/.local/cache/cnot-borrowed-device-20261117')
host, port = sys.argv[1:3]
common = ['-o','BatchMode=yes','-o',f'UserKnownHostsFile={(root / "known_hosts").as_posix()}',
          '-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2',
          '-i','C:/Users/Иван Литвак/.ssh/id_rsa']
script = b'''set -u
cat > /workspace/cnot-borrowed-device-referrer.py <<'PY'
import gc, sys, unittest, types, torch
sys.path.insert(0, '/workspace/cnot-borrowed-device-src/tests')
from cnot_borrowed_device_test import BorrowedDeviceTest
suite=unittest.TestSuite([BorrowedDeviceTest('test_previous_device_restored')])
result=unittest.TextTestRunner(verbosity=1).run(suite)
del suite
gc.collect()
for device in range(torch.cuda.device_count()): torch.cuda.synchronize(device)
torch.cuda.empty_cache()
gc.collect()
print('memory:',[(i,torch.cuda.memory_allocated(i),torch.cuda.memory_reserved(i)) for i in range(torch.cuda.device_count())],flush=True)
def show_refs(t):
  print('tensor:',t.shape,t.device,flush=True)
  for r in gc.get_referrers(t):
    if isinstance(r,types.FrameType): print('frame:',r.f_code.co_name,r.f_code.co_filename,flush=True)
    elif isinstance(r,dict): print('dict keys:',[str(k) for k in list(r.keys())[:30]],flush=True)
    else: print('reference type:',type(r).__name__,flush=True)
for obj in gc.get_objects():
  if isinstance(obj,torch.Tensor) and obj.is_cuda: show_refs(obj)
sys.exit(0 if result.wasSuccessful() else 1)
PY
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}"
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-device-new/libbeam_cnot_owned_domain.so BEAM_TEST_SECOND_GPU=1
timeout 300 compute-sanitizer --tool memcheck --leak-check full python /workspace/cnot-borrowed-device-referrer.py > /workspace/cnot-borrowed-device-referrer.log 2>&1
grep -E 'memory:|tensor:|frame:|dict keys:|reference type:|LEAK SUMMARY|ERROR SUMMARY' /workspace/cnot-borrowed-device-referrer.log
'''
result = subprocess.run(['ssh',*common,'-p',port,f'root@{host}','bash','-s'],
                        input=script,capture_output=True,timeout=350)
print(result.stdout.decode('utf-8','replace'))
print(result.stderr.decode('utf-8','replace'))
sys.exit(result.returncode)
