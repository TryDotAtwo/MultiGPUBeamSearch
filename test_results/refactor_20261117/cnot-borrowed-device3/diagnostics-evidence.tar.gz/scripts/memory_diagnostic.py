from pathlib import Path
import subprocess
import sys

root = Path('D:/100XH100/.local/cache/cnot-borrowed-device-20261117')
host, port = sys.argv[1:3]
common = ['-o','BatchMode=yes','-o',f'UserKnownHostsFile={(root / "known_hosts").as_posix()}',
          '-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2',
          '-i','C:/Users/Иван Литвак/.ssh/id_rsa']
script = b'''set -Eeuo pipefail
cat > /workspace/cnot-borrowed-device-memory-runner.py <<'PY'
import gc, sys, unittest
import torch
sys.path.insert(0, '/workspace/cnot-borrowed-device-src/tests')
import cnot_borrowed_device_test
result = unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromModule(cnot_borrowed_device_test))
def stats(tag):
    print(tag, [(i,torch.cuda.memory_allocated(i),torch.cuda.memory_reserved(i)) for i in range(torch.cuda.device_count())],flush=True)
stats('before')
gc.collect()
for device in range(torch.cuda.device_count()):
    torch.cuda.synchronize(device)
torch.cuda.empty_cache()
gc.collect()
stats('after')
for o in gc.get_objects():
    if isinstance(o,torch.Tensor) and o.is_cuda:
        print('live tensor',tuple(o.shape),o.device,'referrers',[(type(r).__name__, str(r)[:100]) for r in gc.get_referrers(o)[:5]],flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
PY
cd /workspace/cnot-borrowed-device-src
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}"
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-device-new/libbeam_cnot_owned_domain.so
export BEAM_TEST_SECOND_GPU=1
timeout 300 python /workspace/cnot-borrowed-device-memory-runner.py > /workspace/cnot-borrowed-device-memory-runner.log 2>&1
tail -40 /workspace/cnot-borrowed-device-memory-runner.log
'''
result = subprocess.run(['ssh',*common,'-p',port,f'root@{host}','bash','-s'],
                        input=script,capture_output=True,timeout=350)
print(result.stdout.decode('utf-8','replace'))
print(result.stderr.decode('utf-8','replace'))
sys.exit(result.returncode)
