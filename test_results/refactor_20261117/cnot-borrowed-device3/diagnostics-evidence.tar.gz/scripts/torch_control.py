from pathlib import Path
import subprocess
import sys

root = Path('D:/100XH100/.local/cache/cnot-borrowed-device-20261117')
host, port = sys.argv[1:3]
common = ['-o','BatchMode=yes','-o',f'UserKnownHostsFile={(root / "known_hosts").as_posix()}',
          '-o','ConnectTimeout=10','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=2',
          '-i','C:/Users/Иван Литвак/.ssh/id_rsa']
script = b'''set -u
cat > /workspace/cnot-borrowed-device-torch-control.py <<'PY'
import gc, torch
for device in range(torch.cuda.device_count()):
    with torch.cuda.device(device):
        stream=torch.cuda.Stream(device=device)
        with torch.cuda.stream(stream):
            x=torch.arange(512,dtype=torch.int64,device=device)
            y=x*123+9
        stream.synchronize()
        del x,y,stream
gc.collect()
for device in range(torch.cuda.device_count()): torch.cuda.synchronize(device)
torch.cuda.empty_cache()
gc.collect()
print('memory:', [(i,torch.cuda.memory_allocated(i),torch.cuda.memory_reserved(i)) for i in range(torch.cuda.device_count())])
PY
timeout 300 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full python /workspace/cnot-borrowed-device-torch-control.py > /workspace/cnot-borrowed-device-torch-control.log 2>&1
code=$?
tail -12 /workspace/cnot-borrowed-device-torch-control.log
exit "$code"
'''
result = subprocess.run(['ssh',*common,'-p',port,f'root@{host}','bash','-s'],
                        input=script,capture_output=True,timeout=350)
print(result.stdout.decode('utf-8','replace'))
print(result.stderr.decode('utf-8','replace'))
sys.exit(result.returncode)
