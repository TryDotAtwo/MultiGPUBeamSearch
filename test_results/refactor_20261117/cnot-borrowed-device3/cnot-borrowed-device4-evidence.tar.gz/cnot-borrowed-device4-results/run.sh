#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-borrowed-device3-bundle
work=/workspace/cnot-borrowed-device3-src
prior=/workspace/cnot-borrowed-device3-results
out=/workspace/cnot-borrowed-device4-results
mkdir -p "$out" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$out/"
  cp /workspace/cnot-borrowed-device4-run.sh "$out/run.sh"
  tar -czf /workspace/cnot-borrowed-device4-evidence.tar.gz -C /workspace cnot-borrowed-device4-results
  sha256sum /workspace/cnot-borrowed-device4-evidence.tar.gz > /workspace/cnot-borrowed-device4-evidence.sha256
  exit "$code"
}
trap finish EXIT
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-cnot-borrowed-device3
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH" LD_LIBRARY_PATH="/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests:$bundle/overlay/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export TORCH_EXTENSIONS_DIR=/workspace/torch-extensions3 REQUIRE_RUST_CNOT=1
export CUDACXX=/usr/local/cuda/bin/nvcc CUDA_PATH=/usr/local/cuda BEAM_TEST_SECOND_GPU=1
export BEAM_CNOT_OLD_LIBRARY=/workspace/build-cnot-device3-old/libbeam_cnot_owned_domain.so
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-device3-new/libbeam_cnot_owned_domain.so
cd "$work"
verify_source() {
  python - "$work" "$bundle/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
cmp "$out/source-before.txt" "$prior/source-before.txt"
cp "$prior/rust-borrowed.log" "$out/prior-rust-borrowed.log"
cp "$prior/libraries-sha256.txt" "$out/libraries-sha256.txt"
echo RUST_DEVICE_MEMCHECK > "$out/status.txt"
rust_test=$(python - "$prior/rust-borrowed.log" <<'PY'
import re,sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
matches=re.findall(r'Running tests/cnot_borrowed_device\.rs \(([^)]+)\)',s)
assert len(matches)==1, matches
print(matches[0])
PY
)
test -x "$rust_test"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full "$rust_test" --ignored --nocapture > "$out/rust-memcheck.log" 2>&1
cargo fmt --all -- --check > "$out/rust-format.log" 2>&1
echo RUST_EXTENSION >> "$out/status.txt"
timeout 300 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo GPU_SEARCH_ONE >> "$out/status.txt"
timeout 600 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-1" python integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-1.log" 2>&1
echo GPU_SEARCH_TWO >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-2.log" 2>&1
echo FULL_PYTHON >> "$out/status.txt"
timeout 600 python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/cnot-device4-full -p no:cacheprovider > "$out/python-tests.log" 2>&1
echo CROSS_COMPILE >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-device4-cross -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON '-DBEAM_CUDA_ARCHITECTURES=75;80;90;120' -DCMAKE_BUILD_TYPE=Release > "$out/cross-configure.log" 2>&1
timeout 900 cmake --build /workspace/build-cnot-device4-cross --target beam_cnot_owned_domain > "$out/cross-build.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
