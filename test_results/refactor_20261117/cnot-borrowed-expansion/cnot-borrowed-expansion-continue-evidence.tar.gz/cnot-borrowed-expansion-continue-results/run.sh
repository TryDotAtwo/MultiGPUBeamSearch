#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-borrowed-expansion-bundle
cont=/workspace/cnot-borrowed-expansion-continue-bundle
work=/workspace/cnot-borrowed-expansion-src
legacy=/workspace/cnot-borrowed-expansion-legacy-src
prior=/workspace/cnot-borrowed-expansion-results
out=/workspace/cnot-borrowed-expansion-continue-results
private=/workspace/cnot-borrowed-expansion-private
mkdir -p "$legacy" "$out" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$bundle/private-manifest.json" "$cont/legacy-manifest.json" "$cont/run.sh" "$out/"
  tar -czf /workspace/cnot-borrowed-expansion-continue-evidence.tar.gz -C /workspace cnot-borrowed-expansion-continue-results
  sha256sum /workspace/cnot-borrowed-expansion-continue-evidence.tar.gz > /workspace/cnot-borrowed-expansion-continue-evidence.sha256
  exit "$code"
}
trap finish EXIT
tar -xzf "$cont/legacy.tar.gz" -C "$legacy"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-cnot-borrowed-expansion
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests:$bundle/overlay/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export TORCH_EXTENSIONS_DIR=/workspace/torch-expansion REQUIRE_RUST_CNOT=1
export CUDACXX=/usr/local/cuda/bin/nvcc CUDA_PATH=/usr/local/cuda BEAM_TEST_SECOND_GPU=1
export CNOT103_CUDA_ARCHITECTURES=86 CNOT103_REQUIRE_CUDA=1 LIBTORCH_USE_PYTORCH=1 PYTHON="$(command -v python)"
export BEAM_CNOT_OLD_LIBRARY=/workspace/build-cnot-expansion-old/libbeam_cnot_owned_domain.so
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-expansion-new/libbeam_cnot_owned_domain.so
verify_source() {
  python - "$work" "$bundle/source-manifest.json" "$private" "$bundle/private-manifest.json" "$legacy" "$cont/legacy-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
private=Path(sys.argv[3]); pm=json.loads(Path(sys.argv[4]).read_text())
bridge=(private/'native-build/native/src/run_config/execution/mgbs_scorer.rs').read_bytes().replace(b'\r\n',b'\n')
assert hashlib.sha256(bridge).hexdigest()==pm['bridge_sha256']
legacy=Path(sys.argv[5]); lm=json.loads(Path(sys.argv[6]).read_text())
for name,digest in sorted(lm['files'].items()):
    actual=hashlib.sha256((legacy/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'],'and private scorer bridge')
print('verified legacy files',len(lm['files']),'base',lm['commit'])
PY
}
verify_source > "$out/source-before.txt"
head -n 1 "$out/source-before.txt" | cmp - "$prior/source-before.txt"
cp "$prior/libraries-sha256.txt" "$out/libraries-sha256.txt"
sha256sum -c "$out/libraries-sha256.txt" > "$out/libraries-verified.txt"
echo LEGACY_OWNER_BUILD > "$out/status.txt"
cmake -S "$legacy" -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-expansion-legacy -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON -DBEAM_CUDA_ARCHITECTURES=86 -DCMAKE_BUILD_TYPE=Release > "$out/legacy-configure.log" 2>&1
timeout 600 cmake --build /workspace/build-cnot-expansion-legacy --target beam_cnot_owned_domain > "$out/legacy-build.log" 2>&1
sha256sum /workspace/build-cnot-expansion-legacy/libbeam_cnot_owned_domain.so > "$out/legacy-library-sha256.txt"
cd "$work"
echo RUST_OWNER_COMPATIBILITY >> "$out/status.txt"
timeout 300 env BEAM_CNOT_OLD_LIBRARY=/workspace/build-cnot-expansion-legacy/libbeam_cnot_owned_domain.so cargo test --locked -p beam-native-sys --test cnot_borrowed_device -- --ignored --nocapture > "$out/rust-owners.log" 2>&1
rust_test=$(python - "$prior/rust-expansion.log" <<'PY'
import re,sys
from pathlib import Path
matches=re.findall(r'Running tests/cnot_borrowed_expansion\.rs \(([^)]+)\)',Path(sys.argv[1]).read_text())
assert len(matches)==1,matches
print(matches[0])
PY
)
test -x "$rust_test"
echo RUST_MEMCHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full "$rust_test" --ignored --nocapture > "$out/rust-memcheck.log" 2>&1
cargo fmt --all -- --check > "$out/rust-format.log" 2>&1
echo RUST_EXTENSION >> "$out/status.txt"
timeout 300 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo GPU_SEARCH_ONE >> "$out/status.txt"
timeout 600 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-1" python integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-1.log" 2>&1
echo GPU_SEARCH_TWO >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/gpu-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/gpu-2.log" 2>&1
echo SCORER_BUILD >> "$out/status.txt"
cd "$private/native-build/native"
timeout 600 cargo build --locked --release --lib --features cuda > "$out/scorer-build.log" 2>&1
export MGBS_TQP_LIBRARY="$CARGO_TARGET_DIR/release/libcnot103_native.so" MGBS_TQP_MANIFEST="$private/fixture/search-qhat.json"
sha256sum "$MGBS_TQP_LIBRARY" > "$out/scorer-library-sha256.txt"
cd "$work"
echo CHECKPOINT_ONE >> "$out/status.txt"
timeout 300 env CNOT_RUST_EVIDENCE="$out/receipts/checkpoint-1" python integrations/cayleypy_native/tests/cnot_rust_checkpoint.py > "$out/checkpoint-1.log" 2>&1
echo CHECKPOINT_TWO >> "$out/status.txt"
timeout 400 env CNOT_RUST_EVIDENCE="$out/receipts/checkpoint-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_checkpoint.py > "$out/checkpoint-2.log" 2>&1
echo FULL_PYTHON >> "$out/status.txt"
timeout 600 python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/cnot-expansion-continue-full -p no:cacheprovider > "$out/python-tests.log" 2>&1
echo CROSS_COMPILE >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-expansion-cross -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON '-DBEAM_CUDA_ARCHITECTURES=75;80;90;120' -DCMAKE_BUILD_TYPE=Release > "$out/cross-configure.log" 2>&1
timeout 900 cmake --build /workspace/build-cnot-expansion-cross --target beam_cnot_owned_domain > "$out/cross-build.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
