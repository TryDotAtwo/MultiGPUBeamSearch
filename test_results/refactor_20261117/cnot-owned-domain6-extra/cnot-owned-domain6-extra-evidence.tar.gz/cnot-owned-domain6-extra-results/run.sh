#!/bin/bash
set -Eeuo pipefail
out=/workspace/cnot-owned-domain6-extra-results
test_file=/workspace/cnot-owned-domain6-extra-test.py
mkdir -p "$out"
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$test_file" "$out/test-source.py"
  cp /workspace/cnot-owned-domain6-extra-run.sh "$out/run.sh"
  tar -czf /workspace/cnot-owned-domain6-extra-evidence.tar.gz -C /workspace cnot-owned-domain6-extra-results
  sha256sum /workspace/cnot-owned-domain6-extra-evidence.tar.gz > /workspace/cnot-owned-domain6-extra-evidence.sha256
  exit "$code"
}
trap finish EXIT
echo SOURCE_AND_LIBRARY > "$out/status.txt"
printf '%s  %s\n' "$1" "$test_file" | sha256sum -c - > "$out/test-sha256.txt"
sha256sum -c /workspace/cnot-owned-domain5-results/library-sha256.txt > "$out/library-check.txt"
cp /workspace/cnot-owned-domain5-results/library-sha256.txt "$out/library-sha256.txt"
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:${LD_LIBRARY_PATH:-}"
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-owned5/libbeam_cnot_owned_domain.so BEAM_TEST_SECOND_GPU=1
echo GPU_TEST >> "$out/status.txt"
timeout 300 python "$test_file" > "$out/gpu.log" 2>&1
echo MEMCHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full python "$test_file" > "$out/memcheck.log" 2>&1
echo RACECHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool racecheck --error-exitcode 97 python "$test_file" > "$out/racecheck.log" 2>&1
echo OPTIONAL_SKIP >> "$out/status.txt"
env -u BEAM_CNOT_OWNED_LIBRARY python "$test_file" > "$out/optional-skip.log" 2>&1
echo COMPLETE >> "$out/status.txt"
