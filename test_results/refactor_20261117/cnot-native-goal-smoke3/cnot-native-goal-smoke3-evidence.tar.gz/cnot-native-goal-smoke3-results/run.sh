#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-native-goal-smoke3-bundle
work=/workspace/cnot-native-goal-smoke3-src
out=/workspace/cnot-native-goal-smoke3-results
mkdir -p "$work" "$out" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$bundle/run.sh" "$out/"
  tar -czf /workspace/cnot-native-goal-smoke3-evidence.tar.gz -C /workspace cnot-native-goal-smoke3-results
  sha256sum /workspace/cnot-native-goal-smoke3-evidence.tar.gz > /workspace/cnot-native-goal-smoke3-evidence.sha256
  exit "$code"
}
trap finish EXIT
tar -xzf "$bundle/base.tar.gz" -C "$work"
cp -a "$bundle/overlay/." "$work/"
verify_source() {
  python - "$work" "$bundle/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-native-goal-smoke3
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 TORCH_EXTENSIONS_DIR=/workspace/torch-extensions REQUIRE_RUST_CNOT=1
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count())' > "$out/software.txt"
echo BOOTSTRAP > "$out/status.txt"
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
if ! command -v cargo >/dev/null; then
  curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
  sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
{ rustc --version; cargo --version; nvcc --version; } >> "$out/software.txt"
cd "$work"
echo RUST_BUILD >> "$out/status.txt"
timeout 600 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo NATIVE_GOAL_INTERFACE >> "$out/status.txt"
python -c 'from multigpubeamsearch.rust_control import extension; assert hasattr(extension(), "run_cnot_native_goal")' > "$out/interface.log" 2>&1
echo SMOKE_TEST >> "$out/status.txt"
timeout 500 python -m pytest -q integrations/cayleypy_native/tests/test_cnot_rust_controller.py integrations/cayleypy_native/tests/test_cnot_rust_goal.py -k 'not cuda' --tb=short --basetemp /workspace/tmp/cnot-native-goal-smoke3 -p no:cacheprovider > "$out/smoke.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
