#!/bin/bash
set -Eeuo pipefail
work=/workspace/cnot-borrowed-unseen-src
bundle=/workspace/cnot-unseen-bridge-fix-bundle
out=/workspace/cnot-unseen-bridge-sanitizer-results
mkdir -p "$out"
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" /workspace/cnot-unseen-bridge-sanitizer.sh "$out/"
  tar -czf /workspace/cnot-unseen-bridge-sanitizer-evidence.tar.gz -C /workspace cnot-unseen-bridge-sanitizer-results
  sha256sum /workspace/cnot-unseen-bridge-sanitizer-evidence.tar.gz > /workspace/cnot-unseen-bridge-sanitizer-evidence.sha256
  exit "$code"
}
trap finish EXIT
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-cnot-borrowed-unseen
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests:$work/tools" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export TORCH_EXTENSIONS_DIR=/workspace/torch-cnot-unseen-bridge REQUIRE_RUST_CNOT=1
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-unseen-new/libbeam_cnot_owned_domain.so
verify_source() {
  python - "$work" "$bundle/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
cd "$work"
echo VERIFY_SOURCE > "$out/status.txt"
verify_source > "$out/source-before.txt"
echo OWNER_BASELINE >> "$out/status.txt"
set +e
timeout 240 compute-sanitizer --tool memcheck --error-exitcode 97 python -c 'import torch; from multigpubeamsearch.cnot import pack_rows; from multigpubeamsearch.cnot_native import cnot_owners; x=pack_rows((8,4,2,1),device="cuda"); print("OWNERS",cnot_owners(x,2).cpu().tolist())' > "$out/owner-baseline.log" 2>&1
baseline=$?
set -e
printf '%s\n' "$baseline" > "$out/owner-baseline.exit"
echo MEMORY_CHECK_NO_API_ERRORS >> "$out/status.txt"
timeout 600 env CNOT_RUST_EVIDENCE="$out/receipts" compute-sanitizer --tool memcheck --report-api-errors no --error-exitcode 97 python integrations/cayleypy_native/tests/cnot_device_unseen_distributed.py > "$out/memcheck-no-api-errors.log" 2>&1
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
