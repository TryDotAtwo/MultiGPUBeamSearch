#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-unseen-bridge-bundle
work=/workspace/cnot-borrowed-unseen-src
out=/workspace/cnot-unseen-bridge-results
private=/workspace/cnot-unseen-bridge-private
mkdir -p "$out" "$private/native-build" "$private/fixture"
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$bundle/previous-manifest.json" "$bundle/private-manifest.json" "$bundle/bridge-run.sh" "$out/"
  tar -czf /workspace/cnot-unseen-bridge-evidence.tar.gz -C /workspace cnot-unseen-bridge-results
  sha256sum /workspace/cnot-unseen-bridge-evidence.tar.gz > /workspace/cnot-unseen-bridge-evidence.sha256
  exit "$code"
}
trap finish EXIT
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-cnot-borrowed-unseen
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests:$work/tools" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export CUDACXX=/usr/local/cuda/bin/nvcc CUDA_PATH=/usr/local/cuda BEAM_TEST_SECOND_GPU=1
export TORCH_EXTENSIONS_DIR=/workspace/torch-cnot-unseen-bridge REQUIRE_RUST_CNOT=1
export CNOT103_CUDA_ARCHITECTURES=86 CNOT103_REQUIRE_CUDA=1 LIBTORCH_USE_PYTORCH=1 PYTHON="$(command -v python)"
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-unseen-new/libbeam_cnot_owned_domain.so
verify_source() {
  python - "$work" "$1" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
echo VERIFY_PREVIOUS > "$out/status.txt"
verify_source "$bundle/previous-manifest.json" > "$out/source-previous.txt"
tar -xzf "$bundle/native-prepared.tar.gz" -C "$private/native-build"
tar -xzf "$bundle/fixture.tar.gz" -C "$private/fixture"
python - "$private" "$bundle/private-manifest.json" <<'PY' > "$out/private-verified.txt"
import hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
b=(p/'native-build/native/src/run_config/execution/mgbs_scorer.rs').read_bytes().replace(b'\r\n',b'\n')
assert hashlib.sha256(b).hexdigest()==m['bridge_sha256']
print('verified private scorer bridge')
PY
cd "$work"
echo BASELINE_BUILD >> "$out/status.txt"
timeout 600 cargo build --locked -p beam-python > "$out/baseline-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo BASELINE_RED >> "$out/status.txt"
set +e
timeout 900 env CNOT_DEVICE_UNSEEN_RED=1 python "$bundle/overlay/integrations/cayleypy_native/tests/cnot_device_unseen_distributed.py" > "$out/red.log" 2>&1
code=$?
set -e
if [ "$code" -eq 0 ] || ! grep -q 'explicit invalid owned CNOT library was not rejected' "$out/red.log"; then
  echo "baseline did not expose the missing device search bridge: $code" >&2
  exit 1
fi
echo RED_CONFIRMED >> "$out/status.txt"
cp -a "$bundle/overlay/." "$work/"
verify_source "$bundle/source-manifest.json" > "$out/source-before.txt"
echo RUST_BUILD >> "$out/status.txt"
timeout 600 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
sha256sum "$BEAM_CNOT_OWNED_LIBRARY" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so" > "$out/libraries-sha256.txt"
echo BRIDGE_ONE >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/bridge-1" python integrations/cayleypy_native/tests/cnot_device_unseen_distributed.py > "$out/bridge-1.log" 2>&1
echo BRIDGE_TWO >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/bridge-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_device_unseen_distributed.py > "$out/bridge-2.log" 2>&1
echo EXISTING_TWO >> "$out/status.txt"
timeout 900 env MGBS_CNOT_OWNED_LIBRARY="$BEAM_CNOT_OWNED_LIBRARY" CNOT_RUST_EVIDENCE="$out/receipts/existing-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_distributed.py > "$out/existing-2.log" 2>&1
echo SCORER_BUILD >> "$out/status.txt"
cd "$private/native-build/native"
timeout 600 cargo build --locked --release --lib --features cuda > "$out/scorer-build.log" 2>&1
export MGBS_TQP_LIBRARY="$CARGO_TARGET_DIR/release/libcnot103_native.so" MGBS_TQP_MANIFEST="$private/fixture/search-qhat.json"
sha256sum "$MGBS_TQP_LIBRARY" > "$out/scorer-library-sha256.txt"
cd "$work"
echo CHECKPOINT_TWO >> "$out/status.txt"
timeout 600 env MGBS_CNOT_OWNED_LIBRARY="$BEAM_CNOT_OWNED_LIBRARY" CNOT_RUST_EVIDENCE="$out/receipts/checkpoint-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_rust_checkpoint.py > "$out/checkpoint-2.log" 2>&1
echo RUST_WORKSPACE >> "$out/status.txt"
timeout 600 cargo test --workspace --locked > "$out/rust-workspace.log" 2>&1
cargo fmt --all -- --check > "$out/rust-format.log" 2>&1
echo MEMCHECK >> "$out/status.txt"
timeout 900 env CNOT_RUST_EVIDENCE="$out/receipts/memcheck-1" compute-sanitizer --tool memcheck --error-exitcode 97 python integrations/cayleypy_native/tests/cnot_device_unseen_distributed.py > "$out/memcheck.log" 2>&1
verify_source "$bundle/source-manifest.json" > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
