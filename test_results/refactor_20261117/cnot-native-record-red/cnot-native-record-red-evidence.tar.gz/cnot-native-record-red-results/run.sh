#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-native-record-red-bundle
work=/workspace/cnot-native-record-red-src
out=/workspace/cnot-native-record-red-results
mkdir -p "$work" "$out" /workspace/tmp
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$bundle/run.sh" "$out/"
  tar -czf /workspace/cnot-native-record-red-evidence.tar.gz -C /workspace cnot-native-record-red-results
  sha256sum /workspace/cnot-native-record-red-evidence.tar.gz > /workspace/cnot-native-record-red-evidence.sha256
  exit "$code"
}
trap finish EXIT
tar -xzf "$bundle/base.tar.gz" -C "$work"
cp -a "$bundle/overlay/." "$work/"
verify_source() {
  python - "$work" "$bundle/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-native-record-red
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 TORCH_EXTENSIONS_DIR=/workspace/torch-extensions REQUIRE_RUST_CNOT=1
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count())' > "$out/software.txt"
echo BOOTSTRAP > "$out/status.txt"
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
if ! command -v cargo >/dev/null; then
  curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
  sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
{ rustc --version; cargo --version; nvcc --version; } >> "$out/software.txt"
cd "$work"
echo RUST_BUILD >> "$out/status.txt"
timeout 600 cargo build --locked -p beam-python > "$out/rust-build.log" 2>&1
cp "$CARGO_TARGET_DIR/debug/lib_beam_runtime.so" "$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.so"
echo RED_TEST >> "$out/status.txt"
set +e
timeout 400 python -m pytest -q integrations/cayleypy_native/tests/test_cnot_rust_controller.py integrations/cayleypy_native/tests/test_cnot_rust_exchange.py -k 'test_rust_search_owns_record_exchange_without_python_world or test_one_rank_returns_original_rows_without_inspecting_targets' --tb=short --basetemp /workspace/tmp/cnot-native-record-red -p no:cacheprovider > "$out/red.log" 2>&1
code=$?
set -e
if [ "$code" -ne 1 ] || ! grep -q 'legacy Python CNOT record exchange was called' "$out/red.log" || ! grep -q 'matching Rust CNOT record exchange is required' "$out/red.log" || ! grep -q '3 failed' "$out/red.log"; then
  echo "unexpected red test result: $code" >&2
  exit 1
fi
verify_source > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo RED_CONFIRMED >> "$out/status.txt"
echo COMPLETE >> "$out/status.txt"
