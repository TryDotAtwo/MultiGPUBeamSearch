#!/bin/bash
set -Eeuo pipefail
bundle=/workspace/cnot-borrowed-unseen-continuation
work=/workspace/cnot-borrowed-unseen-src
out=/workspace/cnot-borrowed-unseen-continue-results
mkdir -p "$out"
finish() {
  code=$?
  trap - EXIT
  printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
  cp "$bundle/source-manifest.json" "$bundle/previous-manifest.json" "$bundle/continue.sh" "$out/"
  tar -czf /workspace/cnot-borrowed-unseen-continue-evidence.tar.gz -C /workspace cnot-borrowed-unseen-continue-results
  sha256sum /workspace/cnot-borrowed-unseen-continue-evidence.tar.gz > /workspace/cnot-borrowed-unseen-continue-evidence.sha256
  exit "$code"
}
trap finish EXIT
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target-cnot-borrowed-unseen
export PATH="$CARGO_HOME/bin:/usr/local/cuda/bin:$PATH"
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests" PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=4 MAX_JOBS=4 CMAKE_BUILD_PARALLEL_LEVEL=4
export CUDACXX=/usr/local/cuda/bin/nvcc CUDA_PATH=/usr/local/cuda BEAM_TEST_SECOND_GPU=1
export BEAM_CNOT_OLD_LIBRARY=/workspace/build-cnot-unseen-old/libbeam_cnot_owned_domain.so
export BEAM_CNOT_OWNED_LIBRARY=/workspace/build-cnot-unseen-new/libbeam_cnot_owned_domain.so
verify_source() {
  python - "$work" "$1" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
echo VERIFY_ORIGINAL > "$out/status.txt"
verify_source "$bundle/previous-manifest.json" > "$out/source-original.txt"
sha256sum -c "$bundle/libraries-sha256.txt" > "$out/libraries-verified.txt"
cp "$bundle/cnot_borrowed_unseen_test.py" "$work/tests/cnot_borrowed_unseen_test.py"
verify_source "$bundle/source-manifest.json" > "$out/source-before.txt"
cd "$work"
echo GPU_UNSEEN >> "$out/status.txt"
timeout 300 python tests/cnot_borrowed_unseen_test.py > "$out/unseen.log" 2>&1
echo MEMCHECK_UNSEEN >> "$out/status.txt"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full python tests/cnot_borrowed_unseen_test.py > "$out/memcheck.log" 2>&1
echo RACECHECK_UNSEEN >> "$out/status.txt"
timeout 600 compute-sanitizer --tool racecheck --error-exitcode 97 python tests/cnot_borrowed_unseen_test.py > "$out/racecheck.log" 2>&1
echo RUST_WORKSPACE >> "$out/status.txt"
timeout 600 cargo test --workspace --locked > "$out/rust-workspace.log" 2>&1
timeout 300 cargo test --locked -p beam-native-sys --test cnot_borrowed_unseen -- --ignored --nocapture > "$out/rust-unseen.log" 2>&1
rust_test=$(python - "$out/rust-unseen.log" <<'PY'
import re,sys
from pathlib import Path
matches=re.findall(r'Running tests/cnot_borrowed_unseen\.rs \(([^)]+)\)',Path(sys.argv[1]).read_text())
assert len(matches)==1,matches
print(matches[0])
PY
)
test -x "$rust_test"
echo RUST_MEMCHECK >> "$out/status.txt"
timeout 600 compute-sanitizer --tool memcheck --error-exitcode 97 --leak-check full "$rust_test" --ignored --nocapture > "$out/rust-memcheck.log" 2>&1
cargo fmt --all -- --check > "$out/rust-format.log" 2>&1
echo CROSS_COMPILE >> "$out/status.txt"
cmake -S . -DBEAM_STATE_LOGICAL_BYTES=120 -DBEAM_MOVE_COUNT=12 -B /workspace/build-cnot-unseen-cross -G Ninja -DBEAM_CNOT_OWNED_DOMAIN_ONLY=ON '-DBEAM_CUDA_ARCHITECTURES=75;80;90;120' -DCMAKE_BUILD_TYPE=Release > "$out/cross-configure.log" 2>&1
timeout 900 cmake --build /workspace/build-cnot-unseen-cross --target beam_cnot_owned_domain > "$out/cross-build.log" 2>&1
verify_source "$bundle/source-manifest.json" > "$out/source-after.txt"
cmp "$out/source-before.txt" "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
