#!/bin/bash
set -Eeuo pipefail
work=/workspace/cnot-batch-src
private=/workspace/cnot-batch-private
out=/workspace/cnot-batch-results
mkdir -p "$work" "$private/native-build" "$private/fixture" "$out" /workspace/tmp
finish() {
    code=$?
    trap - EXIT
    printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
    cp /workspace/source-manifest.json /workspace/private-manifest.json /workspace/run.sh "$out/"
    tar -czf /workspace/cnot-batch-evidence.tar.gz -C /workspace cnot-batch-results
    sha256sum /workspace/cnot-batch-evidence.tar.gz > /workspace/cnot-batch-evidence.sha256
    exit "$code"
}
trap finish EXIT
tar -xzf /workspace/base.tar.gz -C "$work"
cp -a /workspace/overlay/. "$work/"
tar -xzf /workspace/native-prepared.tar.gz -C "$private/native-build"
tar -xzf /workspace/fixture.tar.gz -C "$private/fixture"
verify_source() {
    python - "$work" /workspace/source-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
    python - "$private" /workspace/private-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
p=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
actual=hashlib.sha256((p/'native-build/native/src/run_config/execution/mgbs_scorer.rs').read_bytes().replace(b'\r\n',b'\n')).hexdigest()
assert actual==m['bridge_sha256'], (actual,m['bridge_sha256'])
print('verified pinned private bridge',actual)
PY
}
verify_source > "$out/source-before.txt"
echo SOURCE_OK > "$out/status.txt"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/tqp-target
export PATH="/workspace/.cargo/bin:/usr/local/cuda/bin:$PATH"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests"
export PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=3 MAX_JOBS=3 CMAKE_BUILD_PARALLEL_LEVEL=3
export TORCH_EXTENSIONS_DIR=/workspace/torch-extensions
export CUDA_PATH=/usr/local/cuda CUDACXX=/usr/local/cuda/bin/nvcc CNOT103_CUDA_ARCHITECTURES=86 CNOT103_REQUIRE_CUDA=1
export LIBTORCH_USE_PYTORCH=1 PYTHON="$(command -v python)"
export LD_LIBRARY_PATH="$(python -c 'import pathlib,torch;print(pathlib.Path(torch.__file__).parent / "lib")'):${LD_LIBRARY_PATH:-}"
if ! command -v cargo >/dev/null; then
    curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
    sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv > "$out/gpus.csv"
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count());assert torch.cuda.device_count()>=2' > "$out/software.txt"
{ rustc --version; cargo --version; nvcc --version; g++ --version | head -n 1; } >> "$out/software.txt"
cd "$private/native-build/native"
echo SCORER_BUILD >> "$out/status.txt"
cargo build --locked --release --lib --features cuda > "$out/scorer-build.log" 2>&1
lib=/workspace/tqp-target/release/libcnot103_native.so
sha256sum "$lib" > "$out/library-sha256.txt"
cd "$work"
echo PYTHON_TESTS >> "$out/status.txt"
timeout 400 python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/pytest -p no:cacheprovider > "$out/python-tests.log" 2>&1
export MGBS_TQP_LIBRARY="$lib" MGBS_TQP_MANIFEST="$private/fixture/search-qhat.json" MGBS_TQP_BATCH_TEST=1
echo CHECKPOINT_TESTS >> "$out/status.txt"
for device in 0 1; do
  timeout 400 env MGBS_TQP_DEVICE="cuda:$device" python -m pytest -q integrations/cayleypy_native/tests/test_cnot_scorer.py --tb=short --basetemp "/workspace/tmp/scorer-$device" -p no:cacheprovider > "$out/scorer-$device.log" 2>&1
done
echo SEARCH_ONE_GPU >> "$out/status.txt"
timeout 600 env MGBS_CNOT_BATCH_EVIDENCE="$out/receipts/gpu-1" python integrations/cayleypy_native/tests/cnot_scorer_batch_distributed.py > "$out/search-1.log" 2>&1
echo SEARCH_TWO_GPU >> "$out/status.txt"
timeout 900 env MGBS_CNOT_BATCH_EVIDENCE="$out/receipts/gpu-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_scorer_batch_distributed.py > "$out/search-2.log" 2>&1
verify_source > "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
