#!/bin/bash
set -Eeuo pipefail
work=/workspace/cnot-goal-src
out=/workspace/cnot-goal-results
mkdir -p "$work" "$out" /workspace/tmp
finish() {
    code=$?
    trap - EXIT
    printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
    cp /workspace/source-manifest.json /workspace/run.sh "$out/"
    tar -czf /workspace/cnot-goal-evidence.tar.gz -C /workspace cnot-goal-results
    sha256sum /workspace/cnot-goal-evidence.tar.gz > /workspace/cnot-goal-evidence.sha256
    exit "$code"
}
trap finish EXIT
tar -xzf /workspace/base.tar.gz -C "$work"
cp "$work/integrations/cayleypy_native/multigpubeamsearch/cnot.py" /workspace/base-cnot.py
sha256sum /workspace/base-cnot.py > "$out/baseline-cnot-sha256.txt"
export TMPDIR=/workspace/tmp PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests"
export TORCH_CUDA_ARCH_LIST=8.6 MAX_JOBS=4 TORCH_EXTENSIONS_DIR=/workspace/torch-extensions
export CNOT_GOAL_BASELINE=/workspace/base-cnot.py
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv > "$out/gpus.csv"
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count());assert torch.cuda.device_count()>=2' > "$out/software.txt"
{ nvcc --version; g++ --version | head -n 1; } >> "$out/software.txt"
cd "$work"
cp /workspace/overlay/integrations/cayleypy_native/tests/test_cnot_collective_goal.py integrations/cayleypy_native/tests/
echo RED_TESTS > "$out/status.txt"
set +e
timeout 180 python -m pytest -q integrations/cayleypy_native/tests/test_cnot_collective_goal.py --tb=short --basetemp /workspace/tmp/red -p no:cacheprovider > "$out/red.log" 2>&1
red=$?
set -e
printf 'RED_EXIT=%s\n' "$red" >> "$out/status.txt"
test "$red" -eq 1
cp -a /workspace/overlay/. "$work/"
verify_source() {
    python - "$work" /workspace/source-manifest.json <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline']); expected.update(m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
assert hashlib.sha256(Path('/workspace/base-cnot.py').read_bytes()).hexdigest()==m['baseline']['integrations/cayleypy_native/multigpubeamsearch/cnot.py']
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
echo PYTHON_TESTS >> "$out/status.txt"
timeout 400 python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/green -p no:cacheprovider > "$out/python-tests.log" 2>&1
echo GPU_ONE >> "$out/status.txt"
timeout 600 env CNOT_GOAL_EVIDENCE="$out/receipts/gpu-1" python integrations/cayleypy_native/tests/cnot_goal_distributed.py > "$out/gpu-1.log" 2>&1
echo GPU_TWO >> "$out/status.txt"
timeout 900 env CNOT_GOAL_EVIDENCE="$out/receipts/gpu-2" torchrun --standalone --nproc-per-node=2 integrations/cayleypy_native/tests/cnot_goal_distributed.py > "$out/gpu-2.log" 2>&1
verify_source > "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
