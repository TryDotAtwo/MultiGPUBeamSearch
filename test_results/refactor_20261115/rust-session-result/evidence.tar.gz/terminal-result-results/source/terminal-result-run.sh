#!/bin/bash
set -Eeuo pipefail
work=/workspace/terminal-result-work
out=/workspace/terminal-result-results
mkdir -p "$work" "$out" /workspace/tmp
finish() {
    code=$?
    trap - EXIT
    printf 'EXIT_CODE=%s\n' "$code" >> "$out/status.txt"
    mkdir -p "$out/source"
    cp /workspace/terminal-result-base.tar.gz /workspace/terminal-result-overlay.tar.gz \
       /workspace/terminal-result-run.sh "$out/source/"
    python - "$out" <<'PY' || true
import json,shutil,sys
from pathlib import Path
out=Path(sys.argv[1])
for evidence in out.glob('gpu-*/results.json'):
    for row in json.loads(evidence.read_text())['records']:
        source=Path(row['run_dir'])
        destination=out/'run-receipts'/evidence.parent.name/source.name
        for path in source.rglob('*'):
            if path.is_file() and not path.is_symlink() and path.suffix in ('.json','.log','.txt') and path.stat().st_size < 10_000_000:
                target=destination/path.relative_to(source); target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(path,target)
for evidence in out.glob('paired/results.json'):
    for row in json.loads(evidence.read_text())['rows']:
        source=Path(row['run_dir']); destination=out/'run-receipts'/'paired'/source.name
        for path in source.glob('*.log'):
            destination.mkdir(parents=True,exist_ok=True); shutil.copy2(path,destination/path.name)
PY
    tar -czf /workspace/terminal-result-evidence.tar.gz -C /workspace terminal-result-results
    sha256sum /workspace/terminal-result-evidence.tar.gz > /workspace/terminal-result-evidence.sha256
    exit "$code"
}
trap finish EXIT
tar -xzf /workspace/terminal-result-base.tar.gz -C "$work"
tar -xzf /workspace/terminal-result-overlay.tar.gz -C "$work" --exclude=manifest.json
tar -xOf /workspace/terminal-result-overlay.tar.gz manifest.json > "$out/source-manifest.json"
verify_source() {
    python - "$work" "$out/source-manifest.json" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); m=json.loads(Path(sys.argv[2]).read_text())
expected=dict(m['baseline'], **m['overlays'])
for name,digest in sorted(expected.items()):
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    assert actual==digest,(name,actual,digest)
print('verified source files',len(expected),'base',m['base_commit'])
PY
}
verify_source > "$out/source-before.txt"
echo SOURCE_OK >> "$out/status.txt"
export TMPDIR=/workspace/tmp CARGO_HOME=/workspace/.cargo RUSTUP_HOME=/workspace/.rustup CARGO_TARGET_DIR=/workspace/target
export PATH="/workspace/.cargo/bin:/usr/local/cuda/bin:$PATH"
export PYTHONPATH="$work/integrations/cayleypy_native:$work/tests"
export PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 TORCH_CUDA_ARCH_LIST=8.6 CARGO_BUILD_JOBS=2 MAX_JOBS=2
export TORCH_EXTENSIONS_DIR=/workspace/torch-extensions
if ! command -v cargo >/dev/null; then
    curl --retry 4 --retry-all-errors --retry-delay 2 --connect-timeout 15 --max-time 120 --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o /workspace/tmp/rustup.sh
    sh /workspace/tmp/rustup.sh -y --profile minimal --no-modify-path > "$out/rustup.log" 2>&1
fi
python -m pip install -q pytest 'cayleypy>=0.1.0' 'cmake==4.1.0' ninja > "$out/pip.log" 2>&1
git clone --depth=1 --branch v3.8.0 https://github.com/NVIDIA/cutlass.git /workspace/cutlass > "$out/cutlass.log" 2>&1
git -C /workspace/cutlass rev-parse HEAD > "$out/cutlass-commit.txt"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv > "$out/gpus.csv"
python -c 'import platform,torch;print(platform.platform());print(torch.__version__);print(torch.version.cuda);print("GPU_COUNT",torch.cuda.device_count());assert torch.cuda.device_count()>=2' > "$out/software.txt"
{ rustc --version; cargo --version; nvcc --version; g++ --version | head -n 1; } >> "$out/software.txt"
cd "$work"
echo RUST_TESTS_START >> "$out/status.txt"
cargo test --workspace --release --locked > "$out/rust-tests.log" 2>&1
echo RUST_TESTS_OK >> "$out/status.txt"
cargo build --release --locked -p beam-python -p beam-cli > "$out/cargo-build.log" 2>&1
module="$work/integrations/cayleypy_native/multigpubeamsearch/_beam_runtime.abi3.so"
cp /workspace/target/release/lib_beam_runtime.so "$module"
mkdir -p "$work/integrations/cayleypy_native/multigpubeamsearch/_bin"
cp /workspace/target/release/beam-runner "$work/integrations/cayleypy_native/multigpubeamsearch/_bin/beam-runner"
sha256sum "$module" /workspace/target/release/beam-runner > "$out/binary-sha256.txt"
python -c 'from multigpubeamsearch import _beam_runtime as m;assert m.SEARCH_TERMINAL_RESULT_VERSION==1;print("TERMINAL_PROTOCOL_V1")' > "$out/protocol.log"
echo RUST_BUILD_OK >> "$out/status.txt"
python -m pytest -q integrations/cayleypy_native/tests --tb=short --basetemp /workspace/tmp/pytest -p no:cacheprovider > "$out/python-tests.log" 2>&1
echo PYTHON_OK >> "$out/status.txt"
for backend in cutlass libtorch; do
    echo "GPU_${backend}_START" >> "$out/status.txt"
    timeout 1800 python tests/public_rust_session_gpu.py --source "$work" --cutlass /workspace/cutlass \
       --cache "/workspace/cache-$backend" --out "$out/gpu-$backend" --backend "$backend" > "$out/gpu-$backend.log" 2>&1
    echo "GPU_${backend}_OK" >> "$out/status.txt"
done
echo PAIR_START >> "$out/status.txt"
timeout 1200 python tests/public_rust_terminal_result_pair_gpu.py --source "$work" --cutlass /workspace/cutlass \
    --cache /workspace/cache-cutlass --out "$out/paired" > "$out/paired.log" 2>&1
echo PAIR_OK >> "$out/status.txt"
verify_source > "$out/source-after.txt"
echo COMPLETE >> "$out/status.txt"
