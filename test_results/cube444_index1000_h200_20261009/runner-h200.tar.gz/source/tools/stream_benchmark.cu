#include "stream_benchmark_common.hpp"
#include "../src/native_input.hpp"

using namespace beam;
using namespace beam::bench;

int main(int argc, char** argv) {
    if (argc != 1 && argc != 2) {
        std::cerr << "usage: stream_benchmark [puzzle_id]\n";
        return 2;
    }
    std::cout << std::unitbuf;
    const std::uint64_t puzzle_id = argc == 2 ? parse_u64(argv[1], "puzzle_id") : 0;
    BEAM_CUDA_CHECK(cudaSetDevice(0));

    std::size_t free_before = 0;
    std::size_t total_before = 0;
    BEAM_CUDA_CHECK(cudaMemGetInfo(&free_before, &total_before));

    const auto input_path = [](const char* name, const char* fallback) {
        const char* value = std::getenv(name);
        return std::filesystem::path(value && value[0] ? value : fallback);
    };
    const auto generator_path = input_path("BEAM_GENERATOR_PATH", "FullBeamNice/generators/p900.json");
    const auto puzzle_info_path = input_path("BEAM_PUZZLE_INFO_JSON", "data/puzzle_info.json");
    const auto test_csv_path = input_path("BEAM_TEST_CSV", "data/test.csv");
    const char* weight_dir_env = std::getenv("BEAM_WEIGHT_DIR");
    const std::filesystem::path weight_dir =
        weight_dir_env != nullptr && weight_dir_env[0] != '\0'
            ? std::filesystem::path(weight_dir_env)
            : std::filesystem::path("build-docker/stream1_weights");
    const std::vector<std::uint8_t> host_generators = beam::input::load_p900_generators(generator_path);
    const State128 host_central = beam::input::load_central_state(puzzle_info_path);
    const State128 host_initial = beam::input::load_initial_state_from_test_csv(test_csv_path, puzzle_id);
    const ZobristTable host_zobrist = make_deterministic_zobrist(0xC0DEC0DEULL);
    const stream1_weights::HostWeightBytes host_weights =
        stream1_weights::load_stream1_weights(weight_dir);
    const Stream1ModelConfig& stream1_model = host_weights.model;
    beam::input::validate_state(host_initial, host_central, stream1_model.num_classes, "benchmark_initial_state");
    const std::uint32_t max_states =
        stream1_model.backend == STREAM1_BACKEND_PIECE_TRANSFORMER
            ? TRANSFORMER_B_MICRO_SWEEP.back() * TRANSFORMER_STREAM1_CONCURRENCY_SWEEP.back()
            : stream1_parent_batch_from_row_budget(B_MICRO_SWEEP.back(), stream1_model) *
                  STREAM1_CONCURRENCY_SWEEP.back();
    const bool synthetic_states = std::getenv("BEAM_STREAM1_SYNTHETIC_STATES") != nullptr;
    const std::vector<State128> host_states = synthetic_states
        ? make_synthetic_state_batch(max_states, stream1_model.state_len, stream1_model.num_classes)
        : make_state_batch(host_initial, max_states, stream1_model.num_classes);
    State128* d_states = device_alloc<State128>(max_states);
    std::uint8_t* d_generators = device_alloc<std::uint8_t>(MOVE_COUNT * STATE_STORAGE_LEN);
    State128* d_central = device_alloc<State128>(1);
    Hash128* d_zobrist = device_alloc<Hash128>(STATE_STORAGE_LEN * STATE_VALUE_PAD);
    BEAM_CUDA_CHECK(cudaMemcpy(d_states, host_states.data(), host_states.size() * sizeof(State128), cudaMemcpyHostToDevice));
    BEAM_CUDA_CHECK(cudaMemcpy(d_generators, host_generators.data(), host_generators.size(), cudaMemcpyHostToDevice));
    BEAM_CUDA_CHECK(cudaMemcpy(d_central, &host_central, sizeof(State128), cudaMemcpyHostToDevice));
    BEAM_CUDA_CHECK(cudaMemcpy(d_zobrist, &host_zobrist[0][0], STATE_STORAGE_LEN * STATE_VALUE_PAD * sizeof(Hash128), cudaMemcpyHostToDevice));
    require_aligned(d_states, alignof(State128), "states");
    require_aligned(d_generators, 16, "generators");
    require_aligned(d_central, alignof(State128), "central");
    require_aligned(d_zobrist, alignof(Hash128), "zobrist");
    stream1_weights::DeviceWeights weights = stream1_weights::upload_weights(host_weights);

    std::filesystem::create_directories("test_results");
    const char* report_env = std::getenv("BEAM_STREAM_BENCH_REPORT");
    const std::string report_path =
        report_env != nullptr ? std::string(report_env) : std::string("test_results/per_stream_benchmark_2026-05-24.md");
    const bool stream_micro_only = std::getenv("BEAM_STREAM_MICRO_ONLY") != nullptr;
    std::ofstream report(report_path);
    report << "# Per Stream Benchmark 2026-05-22\n\n";
    report << "- puzzle_id=" << puzzle_id << "\n";
    report << "- gpu_total_bytes=" << total_before << "\n";
    report << "- gpu_free_before_bytes=" << free_before << "\n";
    report << "- generator_path=" << generator_path.string() << "\n";
    report << "- puzzle_info_path=" << puzzle_info_path.string() << "\n";
    report << "- test_csv_path=" << test_csv_path.string() << "\n";
    report << "- synthetic_states=" << (synthetic_states ? 1 : 0) << "\n";
    report << "- weight_dir=" << weight_dir.string() << "\n";
    report << "- stream1_model_hidden1=" << stream1_model.hidden1 << "\n";
    report << "- stream1_model_hidden2=" << stream1_model.hidden2 << "\n";
    report << "- stream1_model_residual_count=" << stream1_model.residual_count << "\n";
    report << "- stream1_model_output_dim=" << stream1_model.output_dim << "\n";
    report << "- stream1_model_weight_bytes=" << stream1_weights::total_host_weight_bytes(host_weights) << "\n";
    report << "- cuda_architectures=75,86\n";
    report << "- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75\n";
    if (stream1_model.backend == STREAM1_BACKEND_PIECE_TRANSFORMER) {
        report << "- stream1_backend=piece_transformer\n\n";
        std::cout << "stream_benchmark_start=1\n";
        benchmark_stream1_transformer(weights, stream1_model, d_states, max_states, report);
        std::cout << "stream1_transformer_benchmark_done=1\n";
        report << "## Status\n\n";
        report << "- status=pass\n";
        report.close();
        stream1_weights::free_weights(weights);
        cudaFree(d_states);
        cudaFree(d_generators);
        cudaFree(d_central);
        cudaFree(d_zobrist);
        BEAM_CUDA_CHECK(cudaDeviceSynchronize());
        std::cout << "stream_benchmark_report=" << report_path << "\n";
        return 0;
    }
    report << "\n";
    std::cout << "stream_benchmark_start=1\n";
    benchmark_stream1_mlp(weights, stream1_model, d_states, d_generators, max_states, report);
    std::cout << "stream1_benchmark_done=1\n";
    if (std::getenv("BEAM_STREAM1_ONLY") != nullptr) {
        report << "## Status\n\n";
        report << "- status=pass\n";
        report.close();
        stream1_weights::free_weights(weights);
        cudaFree(d_states);
        cudaFree(d_generators);
        cudaFree(d_central);
        cudaFree(d_zobrist);
        BEAM_CUDA_CHECK(cudaDeviceSynchronize());
        std::cout << "stream_benchmark_report=" << report_path << "\n";
        return 0;
    }
    if (!stream_micro_only) {
        benchmark_stream2(d_states, d_generators, d_central, d_zobrist, report);
        std::cout << "stream2_benchmark_done=1\n";
        benchmark_stream3(report);
        std::cout << "stream3_benchmark_done=1\n";
    }
    benchmark_stream4(report);
    std::cout << "stream4_benchmark_done=1\n";

    report << "## Status\n\n";
    report << "- status=pass\n";
    report.close();

    stream1_weights::free_weights(weights);
    cudaFree(d_states);
    cudaFree(d_generators);
    cudaFree(d_central);
    cudaFree(d_zobrist);
    BEAM_CUDA_CHECK(cudaDeviceSynchronize());
    std::cout << "stream_benchmark_report=" << report_path << "\n";
    return 0;
}
