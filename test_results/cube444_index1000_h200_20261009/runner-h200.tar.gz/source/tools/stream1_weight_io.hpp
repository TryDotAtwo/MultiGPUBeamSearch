#pragma once

#include "../src/config.hpp"
#include "../src/native_input.hpp"
#include "../cuda/stream1_transformer_shape.hpp"
#include "../cuda/stream1_transformer_hopper_policy.hpp"

#ifndef BEAM_STREAM1_WEIGHT_IO_MANIFEST_ONLY
#include "cuda_check.hpp"
#include "../cuda/device_weight_verification.cuh"
#include "../cuda/stream1.hpp"

#include <cuda_fp16.h>
#include <cuda_runtime.h>
#endif

#include <cstddef>
#include <cmath>
#include <cstdlib>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace beam::stream1_weights {

inline constexpr std::uint32_t TRANSFORMER_NUM_CLASSES = 120;
inline constexpr std::uint32_t TRANSFORMER_NUM_PIECES = 50;
inline constexpr std::uint32_t TRANSFORMER_MAX_PIECE_SIZE = 3;
inline constexpr std::uint32_t TRANSFORMER_SEQ_LEN = 51;
inline constexpr std::uint32_t TRANSFORMER_D_MODEL = 256;
inline constexpr std::uint32_t TRANSFORMER_NHEAD = 8;
inline constexpr std::uint32_t TRANSFORMER_HEAD_DIM = 32;
inline constexpr std::uint32_t TRANSFORMER_LAYERS = 4;
inline constexpr std::uint32_t TRANSFORMER_FF_DIM = 1024;

struct HostTransformerBlockBytes {
    float qkv_e4m3_scale = 0.f;
    float ff1_e4m3_scale = 0.f;
    float ff2_e4m3_scale = 0.f;
    std::vector<std::byte> ln1_gamma;
    std::vector<std::byte> ln1_beta;
    std::vector<std::byte> attn_qkv_weight;
    std::vector<std::byte> attn_qkv_bias;
    std::vector<std::byte> attn_out_weight;
    std::vector<std::byte> attn_out_bias;
    std::vector<std::byte> ln2_gamma;
    std::vector<std::byte> ln2_beta;
    std::vector<std::byte> ff1_weight;
    std::vector<std::byte> ff1_bias;
    std::vector<std::byte> ff2_weight;
    std::vector<std::byte> ff2_bias;
};

struct HostTransformerBytes {
    std::vector<std::byte> fast_slot_projected;
    std::vector<std::byte> fast_piece_static;
    std::vector<std::byte> cls_token;
    std::vector<std::byte> input_ln_gamma;
    std::vector<std::byte> input_ln_beta;
    std::vector<std::byte> output_ln_gamma;
    std::vector<std::byte> output_ln_beta;
    std::vector<HostTransformerBlockBytes> blocks;
    std::vector<std::byte> output_weight;
    std::vector<std::byte> output_bias;
    std::vector<std::byte> piece_positions;
    std::vector<std::byte> piece_mask;
    std::vector<std::byte> piece_types;
};

struct HostWeightBytes {
    Stream1ModelConfig model;
    // Assigned only after every transformer tensor passed this exact seal
    // and TensorBinding::finish() established complete manifest coverage.
    std::string verified_transformer_manifest;
    std::vector<std::byte> input_weight;
    std::vector<std::byte> input_bias;
    std::vector<std::byte> input_ln_gamma;
    std::vector<std::byte> input_ln_beta;
    std::vector<std::byte> hidden_weight;
    std::vector<std::byte> hidden_bias;
    std::vector<std::byte> hidden_ln_gamma;
    std::vector<std::byte> hidden_ln_beta;
    std::vector<std::vector<std::byte>> residual_fc1_weight;
    std::vector<std::vector<std::byte>> residual_fc1_bias;
    std::vector<std::vector<std::byte>> residual_fc1_ln_gamma;
    std::vector<std::vector<std::byte>> residual_fc1_ln_beta;
    std::vector<std::vector<std::byte>> residual_fc2_weight;
    std::vector<std::vector<std::byte>> residual_fc2_bias;
    std::vector<std::vector<std::byte>> residual_fc2_ln_gamma;
    std::vector<std::vector<std::byte>> residual_fc2_ln_beta;
    std::vector<std::byte> output_weight;
    std::vector<std::byte> output_bias;
    HostTransformerBytes transformer;
};

#ifndef BEAM_STREAM1_WEIGHT_IO_MANIFEST_ONLY
struct DeviceTransformerBlockWeights {
    bool ff2_hopper_fp16 = false;
    bool qkv_hopper_fp16 = false;
    bool ff1_hopper_fp16 = false;
    float qkv_e4m3_scale = 0.f;
    float ff1_e4m3_scale = 0.f;
    float ff2_e4m3_scale = 0.f;
    half* ln1_gamma = nullptr;
    half* ln1_beta = nullptr;
    half* attn_qkv_weight = nullptr;
    half* attn_qkv_bias = nullptr;
    half* attn_out_weight = nullptr;
    half* attn_out_bias = nullptr;
    half* ln2_gamma = nullptr;
    half* ln2_beta = nullptr;
    half* ff1_weight = nullptr;
    half* ff1_bias = nullptr;
    half* ff2_weight = nullptr;
    half* ff2_bias = nullptr;
};

struct DeviceTransformerWeights {
    half* fast_slot_projected = nullptr;
    half* fast_piece_static = nullptr;
    half* cls_token = nullptr;
    half* input_ln_gamma = nullptr;
    half* input_ln_beta = nullptr;
    half* output_ln_gamma = nullptr;
    half* output_ln_beta = nullptr;
    std::vector<DeviceTransformerBlockWeights> blocks;
    half* output_weight = nullptr;
    half* output_bias = nullptr;
    std::uint16_t* piece_positions = nullptr;
    std::uint8_t* piece_mask = nullptr;
    std::uint8_t* piece_types = nullptr;
};

struct DeviceWeights {
    half* input_weight = nullptr;
    half* input_bias = nullptr;
    half* input_ln_gamma = nullptr;
    half* input_ln_beta = nullptr;
    half* hidden_weight = nullptr;
    half* hidden_bias = nullptr;
    half* hidden_ln_gamma = nullptr;
    half* hidden_ln_beta = nullptr;
    std::vector<half*> residual_fc1_weight;
    std::vector<half*> residual_fc1_bias;
    std::vector<half*> residual_fc1_ln_gamma;
    std::vector<half*> residual_fc1_ln_beta;
    std::vector<half*> residual_fc2_weight;
    std::vector<half*> residual_fc2_bias;
    std::vector<half*> residual_fc2_ln_gamma;
    std::vector<half*> residual_fc2_ln_beta;
    half** residual_fc1_weight_table = nullptr;
    half** residual_fc1_bias_table = nullptr;
    half** residual_fc1_ln_gamma_table = nullptr;
    half** residual_fc1_ln_beta_table = nullptr;
    half** residual_fc2_weight_table = nullptr;
    half** residual_fc2_bias_table = nullptr;
    half** residual_fc2_ln_gamma_table = nullptr;
    half** residual_fc2_ln_beta_table = nullptr;
    half* output_weight = nullptr;
    half* output_bias = nullptr;
    DeviceTransformerWeights transformer;
};

struct ScratchAllocation {
    half* hidden1 = nullptr;
    half* hidden2 = nullptr;
    half* residual = nullptr;
    half* output = nullptr;
    half* transformer_tokens = nullptr;
    half* transformer_qkv = nullptr;
    half* transformer_attention_scores_probs = nullptr;
    half* transformer_attention_context = nullptr;
    half* transformer_ff_hidden = nullptr;
    half* transformer_logits = nullptr;
    std::uint32_t* transformer_numeric_error = nullptr;
};
#endif

inline std::string read_text_exact(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        throw std::runtime_error("cannot open required text file: " + path.string());
    }
    return std::string(std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>());
}

inline std::vector<std::byte> read_binary_exact(
    const std::filesystem::path& path,
    std::uint64_t expected_bytes) {
    if (expected_bytes > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        throw std::runtime_error("binary expected size exceeds size_t: " + path.string());
    }
    std::ifstream file(path, std::ios::binary);
    if (!file) {
        throw std::runtime_error("cannot open required binary file: " + path.string());
    }
    std::vector<std::byte> bytes(static_cast<std::size_t>(expected_bytes));
    file.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    const std::size_t actual = static_cast<std::size_t>(file.gcount());
    file.peek();
    if (actual != bytes.size() || !file.eof()) {
        throw std::runtime_error(
            "binary file size mismatch: " + path.string() +
            " expected=" + std::to_string(bytes.size()) +
            " actual_read=" + std::to_string(actual));
    }
    const std::string extension = path.extension().string();
    if (extension == ".fp16" || extension == ".bf16") {
        if (bytes.size() % 2 != 0) {
            throw std::runtime_error("misaligned 16-bit tensor: " + path.string());
        }
        const std::uint16_t exponent_mask = extension == ".fp16" ? 0x7c00U : 0x7f80U;
        for (std::size_t i = 0; i < bytes.size(); i += 2) {
            const auto bits = static_cast<std::uint16_t>(std::to_integer<unsigned>(bytes[i]) |
                (std::to_integer<unsigned>(bytes[i + 1]) << 8U));
            if ((bits & exponent_mask) == exponent_mask) {
                throw std::runtime_error("nonfinite tensor value: " + path.string() +
                    " element=" + std::to_string(i / 2));
            }
        }
    }
    return bytes;
}

inline bool manifest_has_key(const std::string& text, const char* key) {
    return beam::input::json_has_field(text, key);
}

inline std::uint32_t parse_manifest_u32(const std::string& text, const char* key) {
    return beam::input::json_u32_field(text, key);
}

inline std::uint32_t parse_manifest_u32_any(
    const std::string& text,
    const char* primary_key,
    const char* fallback_key) {
    const bool primary_present = manifest_has_key(text, primary_key);
    const bool fallback_present = manifest_has_key(text, fallback_key);
    if (!primary_present) {
        return parse_manifest_u32(text, fallback_key);
    }
    const std::uint32_t primary = parse_manifest_u32(text, primary_key);
    if (!fallback_present) {
        return primary;
    }
    const std::uint32_t fallback = parse_manifest_u32(text, fallback_key);
    if (primary != fallback) {
        throw std::runtime_error(
            "stream1 manifest conflicting uint32 keys: " + std::string(primary_key) +
            "=" + std::to_string(primary) + " " + std::string(fallback_key) +
            "=" + std::to_string(fallback));
    }
    return primary;
}

inline std::string parse_manifest_string(const std::string& text, const char* key) {
    return beam::input::json_string_field(text, key);
}

inline std::string parse_manifest_string_default(
    const std::string& text,
    const char* key,
    const std::string& default_value) {
    return manifest_has_key(text, key) ? parse_manifest_string(text, key) : default_value;
}

inline void require_manifest_u32(
    std::uint32_t actual,
    std::uint32_t expected,
    const char* key,
    const std::string& context) {
    if (actual != expected) {
        throw std::runtime_error(
            context + ": stream1 piece_transformer " + key + " must be " + std::to_string(expected) +
            " got " + std::to_string(actual));
    }
}

inline void require_manifest_string(
    const std::string& actual,
    const char* expected,
    const char* key,
    const std::string& context) {
    if (actual != expected) {
        throw std::runtime_error(
            context + ": stream1 piece_transformer " + key + " must be " + expected + " got " + actual);
    }
}

inline void validate_mlp_model_config(const Stream1ModelConfig& model, const std::string& context) {
    if (model.state_len != STATE_LEN) {
        throw std::runtime_error(context + ": stream1 state_len must match compile-time STATE_LEN");
    }
    if (model.num_classes < STATE_LEN ||
        (model.output_dim != MOVE_COUNT && model.output_dim != STREAM1_SINGLE_SCORE_OUTPUT_DIM)) {
        throw std::runtime_error(context + ": stream1 num_classes/output_dim incompatible with current puzzle");
    }
    if (model.dtype != STREAM1_DTYPE_FP16 && model.dtype != STREAM1_DTYPE_BF16) {
        throw std::runtime_error(context + ": stream1 dtype must be fp16 or bf16");
    }
    if (model.normalization != STREAM1_NORM_NONE && model.normalization != STREAM1_NORM_LAYERNORM) {
        throw std::runtime_error(context + ": stream1 normalization must be none or layernorm");
    }
    if (model.hidden1 == 0U || model.hidden2 == 0U || model.residual_count == 0U) {
        throw std::runtime_error(context + ": stream1 hidden sizes and residual_count must be nonzero");
    }
    if (model.hidden1 < model.hidden2) {
        throw std::runtime_error(context + ": stream1 hidden1 must be >= hidden2 because Stream1 reuses hidden1 scratch for residual output");
    }
    if (model.hidden1 % 8U != 0U || model.hidden2 % 8U != 0U) {
        throw std::runtime_error(context + ": stream1 hidden sizes must be multiples of 8 for TensorOp path");
    }
}

inline std::uint32_t parse_transformer_activation(const std::string& activation, const std::string& context) {
    if (activation == "silu") {
        return STREAM1_ACTIVATION_SILU;
    }
    if (activation == "relu") {
        return STREAM1_ACTIVATION_RELU;
    }
    throw std::runtime_error(context + ": unsupported stream1 piece_transformer activation " + activation);
}

inline void validate_transformer_model_config(
    const Stream1ModelConfig& model,
    const std::string& activation,
    const std::string& pooling,
    const std::string& piece_layout,
    const std::string& piece_embed_mode,
    const std::string& context) {
    if (model.dtype != STREAM1_DTYPE_FP16 && model.dtype != STREAM1_DTYPE_BF16) {
        throw std::runtime_error(context + ": stream1 piece_transformer dtype must be fp16 or bf16");
    }
    require_manifest_u32(model.state_len, static_cast<std::uint32_t>(STATE_LEN), "state_len", context);
    require_manifest_u32(model.output_dim, static_cast<std::uint32_t>(MOVE_COUNT), "output_dim", context);
    require_manifest_u32(model.max_piece_size, 3U, "max_piece_size", context);
    require_manifest_u32(model.d_model, TRANSFORMER_D_MODEL, "d_model", context);
    require_manifest_u32(model.nhead, TRANSFORMER_NHEAD, "nhead", context);
    require_manifest_u32(model.head_dim, TRANSFORMER_HEAD_DIM, "head_dim", context);
    require_manifest_u32(model.transformer_layers, TRANSFORMER_LAYERS, "transformer_layers", context);
    require_manifest_u32(model.ff_dim, TRANSFORMER_FF_DIM, "ff_dim", context);
    require_manifest_string(pooling, "cls", "pooling", context);
    if (piece_layout == "p900") {
        require_manifest_u32(model.num_classes, 120U, "num_classes", context);
        require_manifest_u32(model.num_pieces, 50U, "num_pieces", context);
        require_manifest_u32(model.seq_len, 51U, "seq_len", context);
        require_manifest_string(activation, "silu", "activation", context);
        require_manifest_string(piece_embed_mode, "full_s120", "piece_embed_mode", context);
        return;
    }
    if (piece_layout == "cube4") {
        require_manifest_u32(model.num_classes, 6U, "num_classes", context);
        require_manifest_u32(model.num_pieces, 56U, "num_pieces", context);
        require_manifest_u32(model.seq_len, 57U, "seq_len", context);
        require_manifest_string(activation, "relu", "activation", context);
        require_manifest_string(piece_embed_mode, "piece_local", "piece_embed_mode", context);
        return;
    }
    throw std::runtime_error(context + ": unsupported stream1 piece_transformer piece_layout " + piece_layout);
}

inline Stream1ModelConfig load_stream1_manifest(const std::filesystem::path& dir) {
    const std::filesystem::path manifest_path = dir / "manifest.json";
    const std::string text = read_text_exact(manifest_path);
    const std::string dtype = parse_manifest_string(text, "dtype");
    if (dtype != "fp16" && dtype != "bf16") {
        throw std::runtime_error("stream1 manifest dtype must be fp16 or bf16: " + manifest_path.string());
    }

    Stream1ModelConfig model;
    model.dtype = dtype == "bf16" ? STREAM1_DTYPE_BF16 : STREAM1_DTYPE_FP16;
    const std::string backend = parse_manifest_string_default(text, "backend", "mlp");
    if (backend == "mlp") {
        model.backend = STREAM1_BACKEND_MLP;
        model.state_len = parse_manifest_u32(text, "state_len");
        model.num_classes = parse_manifest_u32(text, "num_classes");
        model.hidden1 = parse_manifest_u32_any(text, "hidden1", "hd1");
        model.hidden2 = parse_manifest_u32_any(text, "hidden2", "hd2");
        model.residual_count = parse_manifest_u32_any(text, "residual_count", "nrd");
        model.output_dim = parse_manifest_u32(text, "output_dim");
        const std::string normalization = parse_manifest_string_default(text, "normalization", "none");
        if (normalization == "layernorm") {
            model.normalization = STREAM1_NORM_LAYERNORM;
        } else if (normalization == "none" || normalization == "batchnorm_folded") {
            model.normalization = STREAM1_NORM_NONE;
        } else {
            throw std::runtime_error("stream1 manifest normalization must be none, batchnorm_folded, or layernorm: " + manifest_path.string());
        }
        validate_mlp_model_config(model, manifest_path.string());
        return model;
    }
    if (backend == "piece_transformer") {
        model.backend = STREAM1_BACKEND_PIECE_TRANSFORMER;
        model.state_len = parse_manifest_u32(text, "state_len");
        model.num_classes = parse_manifest_u32(text, "num_classes");
        model.output_dim = parse_manifest_u32(text, "output_dim");
        model.num_pieces = parse_manifest_u32(text, "num_pieces");
        model.max_piece_size = parse_manifest_u32(text, "max_piece_size");
        model.seq_len = parse_manifest_u32(text, "seq_len");
        model.d_model = parse_manifest_u32(text, "d_model");
        model.nhead = parse_manifest_u32(text, "nhead");
        model.head_dim = parse_manifest_u32(text, "head_dim");
        model.transformer_layers = parse_manifest_u32_any(text, "transformer_layers", "num_layers");
        model.ff_dim = parse_manifest_u32(text, "ff_dim");
        const std::string activation = parse_manifest_string(text, "activation");
        model.activation = parse_transformer_activation(activation, manifest_path.string());
        validate_transformer_model_config(
            model,
            activation,
            parse_manifest_string(text, "pooling"),
            parse_manifest_string(text, "piece_layout"),
            parse_manifest_string(text, "piece_embed_mode"),
            manifest_path.string());
        return model;
    }
    throw std::runtime_error("stream1 manifest backend must be one of accepted values: mlp, piece_transformer: " + manifest_path.string());
}
inline const char* weight_suffix(const Stream1ModelConfig& model) {
    return model.dtype == STREAM1_DTYPE_BF16 ? ".bf16" : ".fp16";
}

inline std::uint64_t fp16_bytes(std::uint64_t count) {
    return count * sizeof(std::uint16_t);
}

inline HostWeightBytes load_stream1_mlp_weights(const std::filesystem::path& dir, const Stream1ModelConfig& model) {
    HostWeightBytes weights;
    weights.model = model;
    const std::string suffix = weight_suffix(model);
    weights.input_weight = read_binary_exact(
        dir / ("input_weight_hxk" + suffix),
        fp16_bytes(static_cast<std::uint64_t>(model.state_len) * model.num_classes * model.hidden1));
    weights.input_bias = read_binary_exact(dir / ("input_bias" + suffix), fp16_bytes(model.hidden1));
    if (model.normalization == STREAM1_NORM_LAYERNORM) {
        weights.input_ln_gamma = read_binary_exact(dir / ("input_ln_gamma" + suffix), fp16_bytes(model.hidden1));
        weights.input_ln_beta = read_binary_exact(dir / ("input_ln_beta" + suffix), fp16_bytes(model.hidden1));
    }
    weights.hidden_weight = read_binary_exact(
        dir / ("hidden_weight_hxk" + suffix),
        fp16_bytes(static_cast<std::uint64_t>(model.hidden1) * model.hidden2));
    weights.hidden_bias = read_binary_exact(dir / ("hidden_bias" + suffix), fp16_bytes(model.hidden2));
    if (model.normalization == STREAM1_NORM_LAYERNORM) {
        weights.hidden_ln_gamma = read_binary_exact(dir / ("hidden_ln_gamma" + suffix), fp16_bytes(model.hidden2));
        weights.hidden_ln_beta = read_binary_exact(dir / ("hidden_ln_beta" + suffix), fp16_bytes(model.hidden2));
    }
    weights.residual_fc1_weight.resize(model.residual_count);
    weights.residual_fc1_bias.resize(model.residual_count);
    weights.residual_fc1_ln_gamma.resize(model.residual_count);
    weights.residual_fc1_ln_beta.resize(model.residual_count);
    weights.residual_fc2_weight.resize(model.residual_count);
    weights.residual_fc2_bias.resize(model.residual_count);
    weights.residual_fc2_ln_gamma.resize(model.residual_count);
    weights.residual_fc2_ln_beta.resize(model.residual_count);
    for (std::uint32_t block = 0; block < model.residual_count; ++block) {
        const std::string prefix = "residual" + std::to_string(block);
        weights.residual_fc1_weight[block] = read_binary_exact(
            dir / (prefix + "_fc1_weight_hxk" + suffix),
            fp16_bytes(static_cast<std::uint64_t>(model.hidden2) * model.hidden2));
        weights.residual_fc1_bias[block] =
            read_binary_exact(dir / (prefix + "_fc1_bias" + suffix), fp16_bytes(model.hidden2));
        if (model.normalization == STREAM1_NORM_LAYERNORM) {
            weights.residual_fc1_ln_gamma[block] =
                read_binary_exact(dir / (prefix + "_fc1_ln_gamma" + suffix), fp16_bytes(model.hidden2));
            weights.residual_fc1_ln_beta[block] =
                read_binary_exact(dir / (prefix + "_fc1_ln_beta" + suffix), fp16_bytes(model.hidden2));
        }
        weights.residual_fc2_weight[block] = read_binary_exact(
            dir / (prefix + "_fc2_weight_hxk" + suffix),
            fp16_bytes(static_cast<std::uint64_t>(model.hidden2) * model.hidden2));
        weights.residual_fc2_bias[block] =
            read_binary_exact(dir / (prefix + "_fc2_bias" + suffix), fp16_bytes(model.hidden2));
        if (model.normalization == STREAM1_NORM_LAYERNORM) {
            weights.residual_fc2_ln_gamma[block] =
                read_binary_exact(dir / (prefix + "_fc2_ln_gamma" + suffix), fp16_bytes(model.hidden2));
            weights.residual_fc2_ln_beta[block] =
                read_binary_exact(dir / (prefix + "_fc2_ln_beta" + suffix), fp16_bytes(model.hidden2));
        }
    }
    weights.output_weight = read_binary_exact(
        dir / ("output_weight_hxk" + suffix),
        fp16_bytes(static_cast<std::uint64_t>(model.hidden2) * model.output_dim));
    weights.output_bias = read_binary_exact(dir / ("output_bias" + suffix), fp16_bytes(model.output_dim));
    return weights;
}

inline float hopper_e4m3_scale_record(const std::string& artifact,const std::string& name,unsigned k) {
    auto start=artifact.find("\""+name+"\"");auto end=artifact.find('}',start);
    if(start==std::string::npos||end==std::string::npos)throw std::runtime_error("Missing FP8 weight record");
    const auto record=artifact.substr(start,end-start);
    if(parse_manifest_string(record,"dtype")!="e4m3fn" || parse_manifest_string(record,"layout")!="column_major_kxn" ||
       parse_manifest_u32(record,"stride_k")!=1 || parse_manifest_u32(record,"stride_n")!=k)
        throw std::runtime_error("Invalid native FP8 layout");
    auto pos=record.find("\"dequant_scale\"");
    if(pos==std::string::npos)throw std::runtime_error("Missing FP8 scale");
    float scale=std::stof(record.substr(record.find(':',pos)+1));
    if(!std::isfinite(scale)||scale<=0)throw std::runtime_error("Invalid FP8 scale");
    return scale;
}

inline HostWeightBytes load_stream1_transformer_weights(const std::filesystem::path& dir, const Stream1ModelConfig& model) {
    HostWeightBytes weights;
    weights.model = model;
    const std::string suffix = weight_suffix(model);
    const std::string artifact = read_text_exact(dir / "manifest.json");
    input::TensorBinding binding(artifact, model.state_len == 96 && model.num_classes == 6);
    const auto read_bound = [&](const std::filesystem::path& path, std::uint64_t size) {
        auto bytes = read_binary_exact(path, size);
        binding.verify(path.filename().string(), bytes);
        return bytes;
    };
    const bool native_fp8 = manifest_has_key(artifact, "schema");
    const bool native_ffn = native_fp8 && parse_manifest_string(artifact,"schema")=="hopper_native_e4m3_experimental_v2";
    if (native_fp8) {
        const char* enabled = std::getenv("BEAM_HOPPER_NATIVE_FP8");
        if (!enabled || std::string(enabled) != "1" ||
            (!native_ffn && parse_manifest_string(artifact,"schema") != "hopper_native_e4m3_experimental_v1") ||
            model.dtype != STREAM1_DTYPE_FP16 || model.state_len != 96 ||
            model.d_model != 256 || model.ff_dim != 1024 || model.transformer_layers != 4 || model.seq_len != 57)
            throw std::runtime_error("Experimental Hopper artifact requires explicit BEAM_HOPPER_NATIVE_FP8=1 and frozen Cube4 shape");
        if(native_ffn && parse_manifest_u32(artifact,"ffn_hidden_inverse_scale")!=16)
            throw std::runtime_error("Native FP8 FFN requires offline hidden inverse scale16");
    }
    HostTransformerBytes& t = weights.transformer;
    t.fast_slot_projected = read_bound(
        dir / ("fast_slot_projected" + suffix),
        fp16_bytes(static_cast<std::uint64_t>(model.max_piece_size) * model.num_classes * model.d_model));
    t.fast_piece_static = read_bound(
        dir / ("fast_piece_static" + suffix),
        fp16_bytes(static_cast<std::uint64_t>(model.num_pieces) * model.d_model));
    t.cls_token = read_bound(dir / ("cls_token" + suffix), fp16_bytes(model.d_model));
    t.input_ln_gamma = read_bound(dir / ("input_ln_gamma" + suffix), fp16_bytes(model.d_model));
    t.input_ln_beta = read_bound(dir / ("input_ln_beta" + suffix), fp16_bytes(model.d_model));
    t.output_ln_gamma = read_bound(dir / ("output_ln_gamma" + suffix), fp16_bytes(model.d_model));
    t.output_ln_beta = read_bound(dir / ("output_ln_beta" + suffix), fp16_bytes(model.d_model));
    t.blocks.resize(model.transformer_layers);
    for (std::uint32_t block = 0; block < model.transformer_layers; ++block) {
        const std::string prefix = "block" + std::to_string(block);
        HostTransformerBlockBytes& b = t.blocks[block];
        b.ln1_gamma = read_bound(dir / (prefix + "_ln1_gamma" + suffix), fp16_bytes(model.d_model));
        b.ln1_beta = read_bound(dir / (prefix + "_ln1_beta" + suffix), fp16_bytes(model.d_model));
        if (native_fp8 && block < 3) {
            b.qkv_e4m3_scale=hopper_e4m3_scale_record(artifact,prefix+"_attn_qkv_weight_hxk.fp16",256);
            b.attn_qkv_weight=read_bound(dir/(prefix+"_attn_qkv_weight_hxk.e4m3"),3ULL*256*256);
        } else {
            b.attn_qkv_weight = read_bound(
                dir / (prefix + "_attn_qkv_weight_hxk" + suffix),
                fp16_bytes(3ULL * model.d_model * model.d_model));
        }
        b.attn_qkv_bias = read_bound(dir / (prefix + "_attn_qkv_bias" + suffix), fp16_bytes(3ULL * model.d_model));
        b.attn_out_weight = read_bound(
            dir / (prefix + "_attn_out_weight_hxk" + suffix),
            fp16_bytes(static_cast<std::uint64_t>(model.d_model) * model.d_model));
        b.attn_out_bias = read_bound(dir / (prefix + "_attn_out_bias" + suffix), fp16_bytes(model.d_model));
        b.ln2_gamma = read_bound(dir / (prefix + "_ln2_gamma" + suffix), fp16_bytes(model.d_model));
        b.ln2_beta = read_bound(dir / (prefix + "_ln2_beta" + suffix), fp16_bytes(model.d_model));
        if(native_ffn && block<3){
            b.ff1_e4m3_scale=hopper_e4m3_scale_record(artifact,prefix+"_ff1_weight_hxk.fp16",256);
            b.ff2_e4m3_scale=hopper_e4m3_scale_record(artifact,prefix+"_ff2_weight_hxk.fp16",1024);
            b.ff1_weight=read_bound(dir/(prefix+"_ff1_weight_hxk.e4m3"),256ULL*1024);
            b.ff2_weight=read_bound(dir/(prefix+"_ff2_weight_hxk.e4m3"),256ULL*1024);
        }else{
            b.ff1_weight = read_bound(dir / (prefix + "_ff1_weight_hxk" + suffix),fp16_bytes(static_cast<std::uint64_t>(model.ff_dim) * model.d_model));
            b.ff2_weight = read_bound(dir / (prefix + "_ff2_weight_hxk" + suffix),fp16_bytes(static_cast<std::uint64_t>(model.d_model) * model.ff_dim));
        }
        b.ff1_bias = read_bound(dir / (prefix + "_ff1_bias" + suffix), fp16_bytes(model.ff_dim));
        b.ff2_bias = read_bound(dir / (prefix + "_ff2_bias" + suffix), fp16_bytes(model.d_model));
    }
    t.output_weight = read_bound(
        dir / ("output_weight_hxk" + suffix),
        fp16_bytes(static_cast<std::uint64_t>(model.output_dim) * model.d_model));
    t.output_bias = read_bound(dir / ("output_bias" + suffix), fp16_bytes(model.output_dim));
    t.piece_positions = read_bound(
        dir / "piece_positions.u16",
        static_cast<std::uint64_t>(model.num_pieces) * model.max_piece_size * sizeof(std::uint16_t));
    t.piece_mask = read_bound(
        dir / "piece_mask.u8",
        static_cast<std::uint64_t>(model.num_pieces) * model.max_piece_size);
    t.piece_types = read_bound(dir / "piece_types.u8", model.num_pieces);
    // Validate semantic indices as well as byte integrity before GPU access.
    std::vector<bool> covered(model.state_len, false);
    const bool has_type_count = manifest_has_key(artifact, "num_piece_types");
    const auto type_count = has_type_count
        ? parse_manifest_u32(artifact, "num_piece_types") : 0U;
    for (std::uint32_t piece = 0; piece < model.num_pieces; ++piece) {
        bool nonempty = false;
        for (std::uint32_t slot = 0; slot < model.max_piece_size; ++slot) {
            const auto i = static_cast<std::size_t>(piece) * model.max_piece_size + slot;
            const auto mask = std::to_integer<unsigned>(t.piece_mask[i]);
            if (mask > 1U) throw std::runtime_error("piece mask must be binary");
            if (mask == 0U) continue;
            const auto pos = std::to_integer<unsigned>(t.piece_positions[2 * i]) |
                (std::to_integer<unsigned>(t.piece_positions[2 * i + 1]) << 8U);
            if (pos >= model.state_len || covered[pos])
                throw std::runtime_error("piece positions must partition logical state");
            covered[pos] = true;
            nonempty = true;
        }
        if (!nonempty) throw std::runtime_error("empty piece");
        if (has_type_count &&
            std::to_integer<unsigned>(t.piece_types[piece]) >= type_count)
            throw std::runtime_error("piece type out of range");
    }
    for (const bool present : covered)
        if (!present) throw std::runtime_error("piece positions omit logical state");
    binding.finish();
    weights.verified_transformer_manifest = artifact;
    return weights;
}

inline HostWeightBytes load_stream1_weights(const std::filesystem::path& dir) {
    const Stream1ModelConfig model = load_stream1_manifest(dir);
    switch (model.backend) {
    case STREAM1_BACKEND_MLP:
        return load_stream1_mlp_weights(dir, model);
    case STREAM1_BACKEND_PIECE_TRANSFORMER:
        return load_stream1_transformer_weights(dir, model);
    default:
        throw std::runtime_error("unsupported Stream1 backend in weight loader");
    }
}

inline std::uint64_t total_host_weight_bytes(const HostWeightBytes& weights) {
    std::uint64_t total = weights.input_weight.size() + weights.input_bias.size() +
        weights.input_ln_gamma.size() + weights.input_ln_beta.size() +
        weights.hidden_weight.size() + weights.hidden_bias.size() +
        weights.hidden_ln_gamma.size() + weights.hidden_ln_beta.size() +
        weights.output_weight.size() + weights.output_bias.size();
    for (std::size_t block = 0; block < weights.residual_fc1_weight.size(); ++block) {
        total += weights.residual_fc1_weight[block].size() + weights.residual_fc1_bias[block].size() +
            weights.residual_fc1_ln_gamma[block].size() + weights.residual_fc1_ln_beta[block].size() +
            weights.residual_fc2_weight[block].size() + weights.residual_fc2_bias[block].size() +
            weights.residual_fc2_ln_gamma[block].size() + weights.residual_fc2_ln_beta[block].size();
    }
    const HostTransformerBytes& t = weights.transformer;
    total += t.fast_slot_projected.size() + t.fast_piece_static.size() + t.cls_token.size() +
        t.input_ln_gamma.size() + t.input_ln_beta.size() + t.output_ln_gamma.size() + t.output_ln_beta.size() +
        t.output_weight.size() + t.output_bias.size() + t.piece_positions.size() + t.piece_mask.size() + t.piece_types.size();
    for (const HostTransformerBlockBytes& b : t.blocks) {
        total += b.ln1_gamma.size() + b.ln1_beta.size() + b.attn_qkv_weight.size() + b.attn_qkv_bias.size() +
            b.attn_out_weight.size() + b.attn_out_bias.size() + b.ln2_gamma.size() + b.ln2_beta.size() +
            b.ff1_weight.size() + b.ff1_bias.size() + b.ff2_weight.size() + b.ff2_bias.size();
    }
    return total;
}

// Freeze this process-level layout policy before allocating scratch or capturing graphs.
inline Stream1TransformerSequencePlan transformer_sequence_plan(const Stream1ModelConfig& model) {
    const char* compact = std::getenv("BEAM_STREAM1_TRANSFORMER_COMPACT57");
    const bool compact57 = model.seq_len == 57U && compact != nullptr && std::strcmp(compact, "1") == 0;
    return make_stream1_transformer_sequence_plan(model.seq_len, compact57 ? 1U : 16U);
}

inline std::uint64_t transformer_attention_score_stride(const Stream1ModelConfig& model) {
    const auto sequence = make_stream1_transformer_sequence_plan(model.seq_len, 16U);
    const std::uint64_t row_stride = sequence.padded_seq_len;
    return row_stride * row_stride + row_stride * model.head_dim;
}

struct TransformerScratchBytePlan {
    std::uint64_t rows = 0;
    std::uint32_t logical_seq_len = 0;
    std::uint32_t padded_seq_len = 0;
    std::uint64_t token_bytes = 0;
    std::uint64_t qkv_bytes = 0;
    std::uint64_t attention_bytes = 0;
    std::uint64_t context_bytes = 0;
    std::uint64_t ff_hidden_bytes = 0;
    std::uint64_t logits_bytes = 0;

    std::uint64_t total_bytes() const {
        return token_bytes + qkv_bytes + attention_bytes + context_bytes + ff_hidden_bytes + logits_bytes;
    }
};

inline TransformerScratchBytePlan transformer_scratch_byte_plan(const Stream1ModelConfig& model, std::uint64_t rows) {
    const auto sequence = transformer_sequence_plan(model);
    TransformerScratchBytePlan plan;
    plan.rows = rows;
    plan.logical_seq_len = sequence.logical_seq_len;
    plan.padded_seq_len = sequence.padded_seq_len;
    plan.token_bytes = fp16_bytes(rows * sequence.padded_seq_len * model.d_model);
    plan.qkv_bytes = fp16_bytes(rows * sequence.padded_seq_len * 3ULL * model.d_model);
    plan.attention_bytes = fp16_bytes(rows * model.nhead * transformer_attention_score_stride(model));
    plan.context_bytes = fp16_bytes(rows * sequence.padded_seq_len * model.d_model);
    plan.ff_hidden_bytes = fp16_bytes(rows * sequence.padded_seq_len * model.ff_dim);
    plan.logits_bytes = fp16_bytes(rows * model.output_dim);
    return plan;
}

inline std::uint64_t transformer_scratch_bytes_for_rows(const Stream1ModelConfig& model, std::uint64_t rows) {
    return transformer_scratch_byte_plan(model, rows).total_bytes();
}

inline std::uint64_t stream1_scratch_bytes(
    const Stream1ModelConfig& model,
    std::uint32_t b_micro,
    std::uint32_t lane_count) {
    const std::uint64_t rows = stream1_inference_rows(b_micro, model) * lane_count;
    switch (model.backend) {
    case STREAM1_BACKEND_MLP:
        return fp16_bytes(rows * (static_cast<std::uint64_t>(model.hidden1) + 2ULL * model.hidden2 + model.output_dim));
    case STREAM1_BACKEND_PIECE_TRANSFORMER:
        return transformer_scratch_bytes_for_rows(model, rows) + sizeof(std::uint32_t);
    default:
        throw std::runtime_error("unsupported Stream1 backend in scratch byte helper");
    }
}

inline std::uint64_t total_device_weight_bytes(const HostWeightBytes& weights) {
    return total_host_weight_bytes(weights);
}

#ifndef BEAM_STREAM1_WEIGHT_IO_MANIFEST_ONLY
inline const half* weight_half_data(const std::vector<std::byte>& bytes) {
    return reinterpret_cast<const half*>(bytes.data());
}

inline void copy_bytes_to_device(void* dst, const std::vector<std::byte>& bytes, const char* name) {
    if (dst == nullptr || bytes.empty()) {
        throw std::runtime_error(std::string("invalid device copy input: ") + name);
    }
    BEAM_CUDA_CHECK(cudaMemcpy(dst, bytes.data(), bytes.size(), cudaMemcpyHostToDevice));
    verify_device_weight_bytes(dst, bytes, name);
}

inline void require_aligned(const void* ptr, std::uintptr_t alignment, const char* name) {
    if (reinterpret_cast<std::uintptr_t>(ptr) % alignment != 0) {
        throw std::runtime_error(std::string("device pointer alignment failed: ") + name);
    }
}

template <typename T>
inline void alloc_and_copy_typed(T*& dst, const std::vector<std::byte>& src, const char* name) {
    BEAM_CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&dst), src.size()));
    copy_bytes_to_device(dst, src, name);
    require_aligned(dst, 16, name);
}

inline void alloc_and_copy(half*& dst, const std::vector<std::byte>& src, const char* name) {
    alloc_and_copy_typed(dst, src, name);
}

inline std::vector<std::byte> pack_kxn_column_major_2byte(
    const std::vector<std::byte>& src,
    std::uint32_t k_count,
    std::uint32_t n_count) {
    const std::size_t expected = static_cast<std::size_t>(k_count) * n_count * 2U;
    if (src.size() != expected) {
        throw std::runtime_error("Hopper weight pack expects a two-byte KxN tensor");
    }
    std::vector<std::byte> dst(expected);
    for (std::uint32_t k = 0; k < k_count; ++k) {
        for (std::uint32_t n = 0; n < n_count; ++n) {
            const std::size_t src_offset = (static_cast<std::size_t>(k) * n_count + n) * 2U;
            const std::size_t dst_offset = (static_cast<std::size_t>(n) * k_count + k) * 2U;
            dst[dst_offset] = src[src_offset];
            dst[dst_offset + 1U] = src[src_offset + 1U];
        }
    }
    return dst;
}

inline void alloc_managed_pointer_table(half**& table, const std::vector<half*>& ptrs, const char* name) {
    if (ptrs.empty()) {
        table = nullptr;
        return;
    }
    BEAM_CUDA_CHECK(cudaMallocManaged(&table, ptrs.size() * sizeof(half*)));
    for (std::size_t i = 0; i < ptrs.size(); ++i) {
        table[i] = ptrs[i];
    }
    BEAM_CUDA_CHECK(cudaDeviceSynchronize());
    require_aligned(table, alignof(half*), name);
}

inline void upload_transformer_weights(const HostWeightBytes& host, DeviceWeights& device) {
    const HostTransformerBytes& h = host.transformer;
    DeviceTransformerWeights& d = device.transformer;
    alloc_and_copy(d.fast_slot_projected, h.fast_slot_projected, "fast_slot_projected");
    alloc_and_copy(d.fast_piece_static, h.fast_piece_static, "fast_piece_static");
    alloc_and_copy(d.cls_token, h.cls_token, "cls_token");
    alloc_and_copy(d.input_ln_gamma, h.input_ln_gamma, "input_ln_gamma");
    alloc_and_copy(d.input_ln_beta, h.input_ln_beta, "input_ln_beta");
    alloc_and_copy(d.output_ln_gamma, h.output_ln_gamma, "output_ln_gamma");
    alloc_and_copy(d.output_ln_beta, h.output_ln_beta, "output_ln_beta");
    d.blocks.resize(h.blocks.size());
    const Stream1TransformerHopperMode qkv_hopper_mode = select_stream1_transformer_hopper_mode(
        std::getenv("BEAM_STREAM1_TRANSFORMER_HOPPER"),
        std::getenv("BEAM_STREAM1_TRANSFORMER_HOPPER_QKV"));
    const Stream1TransformerHopperMode ff1_hopper_mode = select_stream1_transformer_hopper_mode(
        std::getenv("BEAM_STREAM1_TRANSFORMER_HOPPER"),
        std::getenv("BEAM_STREAM1_TRANSFORMER_HOPPER_FF1"));
    const auto ff2_hopper_mode = parse_stream1_transformer_hopper_mode(
        std::getenv("BEAM_STREAM1_TRANSFORMER_HOPPER_FF2"));
    const bool hopper_packed_weights =
        ff2_hopper_mode != Stream1TransformerHopperMode::Off ||
        qkv_hopper_mode != Stream1TransformerHopperMode::Off ||
        ff1_hopper_mode != Stream1TransformerHopperMode::Off;
    if (ff2_hopper_mode == Stream1TransformerHopperMode::Fp8E4m3 ||
        qkv_hopper_mode == Stream1TransformerHopperMode::Fp8E4m3 ||
        ff1_hopper_mode == Stream1TransformerHopperMode::Fp8E4m3) {
        throw std::runtime_error(
            "FP8 E4M3 Hopper weights require the dedicated quantized loader; quality is not qualified yet");
    }
    if (hopper_packed_weights && host.model.dtype != STREAM1_DTYPE_FP16) {
        throw std::runtime_error("Hopper packed Stream1 weights currently require FP16 model weights");
    }
    const auto env_enabled = [](const char* name) {
        const char* value = std::getenv(name);
        return value != nullptr && std::strcmp(value, "1") == 0;
    };
    if (ff2_hopper_mode != Stream1TransformerHopperMode::Off) {
        int device=0; cudaDeviceProp props{};
        BEAM_CUDA_CHECK(cudaGetDevice(&device));
        BEAM_CUDA_CHECK(cudaGetDeviceProperties(&props,device));
        if (props.major!=9 || host.model.d_model!=256 || host.model.ff_dim!=1024 ||
            host.model.num_pieces!=56 || host.model.transformer_layers!=4 ||
            !env_enabled("BEAM_STREAM1_TRANSFORMER_COMPACT57"))
            throw std::runtime_error("Hopper FP16 FF2 requires SM90 compact57 Cube4 D256 FF1024 L4");
        for(const auto& b:h.blocks) if(b.ff2_e4m3_scale>0)
            throw std::runtime_error("Hopper FP16 FF2 cannot consume an FP8 FFN artifact");
    }
    if (hopper_packed_weights &&
        (!env_enabled("BEAM_STREAM1_TRANSFORMER_FINAL_CLS_ONLY") ||
         !env_enabled("BEAM_STREAM1_TRANSFORMER_FINAL_CLS_ATTENTION") ||
         !env_enabled("BEAM_STREAM1_TRANSFORMER_FINAL_CLS_SPLIT_QKV"))) {
        throw std::runtime_error(
            "Hopper packed Stream1 weights require FINAL_CLS_ONLY=1, "
            "FINAL_CLS_ATTENTION=1, and FINAL_CLS_SPLIT_QKV=1");
    }
    for (std::size_t i = 0; i < h.blocks.size(); ++i) {
        const std::string prefix = "block" + std::to_string(i);
        const HostTransformerBlockBytes& hb = h.blocks[i];
        DeviceTransformerBlockWeights& db = d.blocks[i];
        db.qkv_e4m3_scale = hb.qkv_e4m3_scale;
        db.ff1_e4m3_scale = hb.ff1_e4m3_scale;
        db.ff2_e4m3_scale = hb.ff2_e4m3_scale;
        if (hb.qkv_e4m3_scale > 0) {
            int device=0; cudaDeviceProp props{};
            BEAM_CUDA_CHECK(cudaGetDevice(&device)); BEAM_CUDA_CHECK(cudaGetDeviceProperties(&props,device));
            if(props.major!=9 || host.model.activation!=STREAM1_ACTIVATION_RELU ||
               !env_enabled("BEAM_STREAM1_TRANSFORMER_COMPACT57") ||
               !env_enabled("BEAM_STREAM1_TRANSFORMER_FINAL_CLS_ONLY") ||
               env_enabled("BEAM_STREAM1_TRANSFORMER_DUAL_INPUT_LN"))
                throw std::runtime_error("Native FP8 requires SM90, ReLU, compact57, final CLS, no dual input LN");
        }
        alloc_and_copy(db.ln1_gamma, hb.ln1_gamma, (prefix + "_ln1_gamma").c_str());
        alloc_and_copy(db.ln1_beta, hb.ln1_beta, (prefix + "_ln1_beta").c_str());
        const bool pack_qkv = hb.qkv_e4m3_scale == 0 && stream1_transformer_hopper_uses_packed_full_token_weight(
            qkv_hopper_mode, static_cast<unsigned>(i), static_cast<unsigned>(h.blocks.size()));
        const bool pack_ff1 = hb.ff1_e4m3_scale == 0 && stream1_transformer_hopper_uses_packed_full_token_weight(
            ff1_hopper_mode, static_cast<unsigned>(i), static_cast<unsigned>(h.blocks.size()));
        db.qkv_hopper_fp16 = pack_qkv;
        db.ff1_hopper_fp16 = pack_ff1;
        const std::vector<std::byte> qkv_packed = pack_qkv
            ? pack_kxn_column_major_2byte(hb.attn_qkv_weight, host.model.d_model, 3U * host.model.d_model)
            : std::vector<std::byte>{};
        const std::vector<std::byte> ff1_packed = pack_ff1
            ? pack_kxn_column_major_2byte(hb.ff1_weight, host.model.d_model, host.model.ff_dim)
            : std::vector<std::byte>{};
        db.ff2_hopper_fp16 = stream1_transformer_hopper_uses_packed_full_token_weight(
            ff2_hopper_mode, static_cast<unsigned>(i), static_cast<unsigned>(h.blocks.size()));
        const auto ff2_packed = db.ff2_hopper_fp16
            ? pack_kxn_column_major_2byte(hb.ff2_weight, host.model.ff_dim, host.model.d_model)
            : std::vector<std::byte>{};
        alloc_and_copy(db.attn_qkv_weight, pack_qkv ? qkv_packed : hb.attn_qkv_weight, (prefix + "_attn_qkv_weight").c_str());
        alloc_and_copy(db.attn_qkv_bias, hb.attn_qkv_bias, (prefix + "_attn_qkv_bias").c_str());
        alloc_and_copy(db.attn_out_weight, hb.attn_out_weight, (prefix + "_attn_out_weight").c_str());
        alloc_and_copy(db.attn_out_bias, hb.attn_out_bias, (prefix + "_attn_out_bias").c_str());
        alloc_and_copy(db.ln2_gamma, hb.ln2_gamma, (prefix + "_ln2_gamma").c_str());
        alloc_and_copy(db.ln2_beta, hb.ln2_beta, (prefix + "_ln2_beta").c_str());
        alloc_and_copy(db.ff1_weight, pack_ff1 ? ff1_packed : hb.ff1_weight, (prefix + "_ff1_weight").c_str());
        alloc_and_copy(db.ff1_bias, hb.ff1_bias, (prefix + "_ff1_bias").c_str());
        alloc_and_copy(db.ff2_weight, db.ff2_hopper_fp16 ? ff2_packed : hb.ff2_weight, (prefix + "_ff2_weight").c_str());
        alloc_and_copy(db.ff2_bias, hb.ff2_bias, (prefix + "_ff2_bias").c_str());
    }
    alloc_and_copy(d.output_weight, h.output_weight, "output_weight");
    alloc_and_copy(d.output_bias, h.output_bias, "output_bias");
    alloc_and_copy_typed(d.piece_positions, h.piece_positions, "piece_positions");
    alloc_and_copy_typed(d.piece_mask, h.piece_mask, "piece_mask");
    alloc_and_copy_typed(d.piece_types, h.piece_types, "piece_types");
}

inline void free_weights(DeviceWeights& device);

inline DeviceWeights upload_weights(const HostWeightBytes& host) {
    DeviceWeights device;
    try {
        if (host.model.backend == STREAM1_BACKEND_PIECE_TRANSFORMER) {
            upload_transformer_weights(host, device);
            return device;
        }
        if (host.model.backend != STREAM1_BACKEND_MLP) {
            throw std::runtime_error("unsupported Stream1 backend in upload_weights");
        }
        alloc_and_copy(device.input_weight, host.input_weight, "input_weight");
        alloc_and_copy(device.input_bias, host.input_bias, "input_bias");
        if (host.model.normalization == STREAM1_NORM_LAYERNORM) {
            alloc_and_copy(device.input_ln_gamma, host.input_ln_gamma, "input_ln_gamma");
            alloc_and_copy(device.input_ln_beta, host.input_ln_beta, "input_ln_beta");
        }
        alloc_and_copy(device.hidden_weight, host.hidden_weight, "hidden_weight");
        alloc_and_copy(device.hidden_bias, host.hidden_bias, "hidden_bias");
        if (host.model.normalization == STREAM1_NORM_LAYERNORM) {
            alloc_and_copy(device.hidden_ln_gamma, host.hidden_ln_gamma, "hidden_ln_gamma");
            alloc_and_copy(device.hidden_ln_beta, host.hidden_ln_beta, "hidden_ln_beta");
        }
        device.residual_fc1_weight.resize(host.model.residual_count);
        device.residual_fc1_bias.resize(host.model.residual_count);
        device.residual_fc1_ln_gamma.resize(host.model.residual_count);
        device.residual_fc1_ln_beta.resize(host.model.residual_count);
        device.residual_fc2_weight.resize(host.model.residual_count);
        device.residual_fc2_bias.resize(host.model.residual_count);
        device.residual_fc2_ln_gamma.resize(host.model.residual_count);
        device.residual_fc2_ln_beta.resize(host.model.residual_count);
        for (std::uint32_t block = 0; block < host.model.residual_count; ++block) {
            const std::string prefix = "residual" + std::to_string(block);
            alloc_and_copy(device.residual_fc1_weight[block], host.residual_fc1_weight[block], (prefix + "_fc1_weight").c_str());
            alloc_and_copy(device.residual_fc1_bias[block], host.residual_fc1_bias[block], (prefix + "_fc1_bias").c_str());
            if (host.model.normalization == STREAM1_NORM_LAYERNORM) {
                alloc_and_copy(device.residual_fc1_ln_gamma[block], host.residual_fc1_ln_gamma[block], (prefix + "_fc1_ln_gamma").c_str());
                alloc_and_copy(device.residual_fc1_ln_beta[block], host.residual_fc1_ln_beta[block], (prefix + "_fc1_ln_beta").c_str());
            }
            alloc_and_copy(device.residual_fc2_weight[block], host.residual_fc2_weight[block], (prefix + "_fc2_weight").c_str());
            alloc_and_copy(device.residual_fc2_bias[block], host.residual_fc2_bias[block], (prefix + "_fc2_bias").c_str());
            if (host.model.normalization == STREAM1_NORM_LAYERNORM) {
                alloc_and_copy(device.residual_fc2_ln_gamma[block], host.residual_fc2_ln_gamma[block], (prefix + "_fc2_ln_gamma").c_str());
                alloc_and_copy(device.residual_fc2_ln_beta[block], host.residual_fc2_ln_beta[block], (prefix + "_fc2_ln_beta").c_str());
            }
        }
        alloc_managed_pointer_table(device.residual_fc1_weight_table, device.residual_fc1_weight, "residual_fc1_weight_table");
        alloc_managed_pointer_table(device.residual_fc1_bias_table, device.residual_fc1_bias, "residual_fc1_bias_table");
        alloc_managed_pointer_table(device.residual_fc2_weight_table, device.residual_fc2_weight, "residual_fc2_weight_table");
        alloc_managed_pointer_table(device.residual_fc2_bias_table, device.residual_fc2_bias, "residual_fc2_bias_table");
        if (host.model.normalization == STREAM1_NORM_LAYERNORM) {
            alloc_managed_pointer_table(device.residual_fc1_ln_gamma_table, device.residual_fc1_ln_gamma, "residual_fc1_ln_gamma_table");
            alloc_managed_pointer_table(device.residual_fc1_ln_beta_table, device.residual_fc1_ln_beta, "residual_fc1_ln_beta_table");
            alloc_managed_pointer_table(device.residual_fc2_ln_gamma_table, device.residual_fc2_ln_gamma, "residual_fc2_ln_gamma_table");
            alloc_managed_pointer_table(device.residual_fc2_ln_beta_table, device.residual_fc2_ln_beta, "residual_fc2_ln_beta_table");
        }
        alloc_and_copy(device.output_weight, host.output_weight, "output_weight");
        alloc_and_copy(device.output_bias, host.output_bias, "output_bias");
        return device;
    } catch (...) {
        free_weights(device);
        throw;
    }
}

inline void free_weights(DeviceWeights& device) {
    cudaFree(device.input_weight);
    cudaFree(device.input_bias);
    cudaFree(device.input_ln_gamma);
    cudaFree(device.input_ln_beta);
    cudaFree(device.hidden_weight);
    cudaFree(device.hidden_bias);
    cudaFree(device.hidden_ln_gamma);
    cudaFree(device.hidden_ln_beta);
    for (half* ptr : device.residual_fc1_weight) {
        cudaFree(ptr);
    }
    for (half* ptr : device.residual_fc1_bias) {
        cudaFree(ptr);
    }
    for (half* ptr : device.residual_fc1_ln_gamma) {
        cudaFree(ptr);
    }
    for (half* ptr : device.residual_fc1_ln_beta) {
        cudaFree(ptr);
    }
    for (half* ptr : device.residual_fc2_weight) {
        cudaFree(ptr);
    }
    for (half* ptr : device.residual_fc2_bias) {
        cudaFree(ptr);
    }
    for (half* ptr : device.residual_fc2_ln_gamma) {
        cudaFree(ptr);
    }
    for (half* ptr : device.residual_fc2_ln_beta) {
        cudaFree(ptr);
    }
    cudaFree(device.residual_fc1_weight_table);
    cudaFree(device.residual_fc1_bias_table);
    cudaFree(device.residual_fc1_ln_gamma_table);
    cudaFree(device.residual_fc1_ln_beta_table);
    cudaFree(device.residual_fc2_weight_table);
    cudaFree(device.residual_fc2_bias_table);
    cudaFree(device.residual_fc2_ln_gamma_table);
    cudaFree(device.residual_fc2_ln_beta_table);
    cudaFree(device.output_weight);
    cudaFree(device.output_bias);
    DeviceTransformerWeights& t = device.transformer;
    cudaFree(t.fast_slot_projected);
    cudaFree(t.fast_piece_static);
    cudaFree(t.cls_token);
    cudaFree(t.input_ln_gamma);
    cudaFree(t.input_ln_beta);
    cudaFree(t.output_ln_gamma);
    cudaFree(t.output_ln_beta);
    for (DeviceTransformerBlockWeights& b : t.blocks) {
        cudaFree(b.ln1_gamma);
        cudaFree(b.ln1_beta);
        cudaFree(b.attn_qkv_weight);
        cudaFree(b.attn_qkv_bias);
        cudaFree(b.attn_out_weight);
        cudaFree(b.attn_out_bias);
        cudaFree(b.ln2_gamma);
        cudaFree(b.ln2_beta);
        cudaFree(b.ff1_weight);
        cudaFree(b.ff1_bias);
        cudaFree(b.ff2_weight);
        cudaFree(b.ff2_bias);
    }
    cudaFree(t.output_weight);
    cudaFree(t.output_bias);
    cudaFree(t.piece_positions);
    cudaFree(t.piece_mask);
    cudaFree(t.piece_types);
    device = DeviceWeights{};
}

inline void free_stream1_scratch(ScratchAllocation& scratch);

inline ScratchAllocation alloc_stream1_scratch(
    const Stream1ModelConfig& model,
    std::uint32_t b_micro,
    std::uint32_t lane_count) {
    ScratchAllocation scratch;
    try {
        const std::uint64_t rows = stream1_inference_rows(b_micro, model) * lane_count;
        if (model.backend == STREAM1_BACKEND_MLP) {
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.hidden1, rows * model.hidden1 * sizeof(half)));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.hidden2, rows * model.hidden2 * sizeof(half)));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.residual, rows * model.hidden2 * sizeof(half)));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.output, rows * model.output_dim * sizeof(half)));
            return scratch;
        }
        if (model.backend == STREAM1_BACKEND_PIECE_TRANSFORMER) {
            const TransformerScratchBytePlan plan = transformer_scratch_byte_plan(model, rows);
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.transformer_tokens, plan.token_bytes));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.transformer_qkv, plan.qkv_bytes));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.transformer_attention_scores_probs, plan.attention_bytes));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.transformer_attention_context, plan.context_bytes));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.transformer_ff_hidden, plan.ff_hidden_bytes));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.transformer_logits, plan.logits_bytes));
            BEAM_CUDA_CHECK(cudaMalloc(&scratch.transformer_numeric_error, sizeof(std::uint32_t)));
            BEAM_CUDA_CHECK(cudaMemset(scratch.transformer_numeric_error, 0, sizeof(std::uint32_t)));
            return scratch;
        }
        throw std::runtime_error("unsupported Stream1 backend in scratch allocation");
    } catch (...) {
        free_stream1_scratch(scratch);
        throw;
    }
}
inline void free_stream1_scratch(ScratchAllocation& scratch) {
    cudaFree(scratch.hidden1);
    cudaFree(scratch.hidden2);
    cudaFree(scratch.residual);
    cudaFree(scratch.output);
    cudaFree(scratch.transformer_tokens);
    cudaFree(scratch.transformer_qkv);
    cudaFree(scratch.transformer_attention_scores_probs);
    cudaFree(scratch.transformer_attention_context);
    cudaFree(scratch.transformer_ff_hidden);
    cudaFree(scratch.transformer_logits);
    cudaFree(scratch.transformer_numeric_error);
    scratch = ScratchAllocation{};
}

inline Stream1NetworkDims network_dims(const Stream1ModelConfig& model) {
    if (model.backend != STREAM1_BACKEND_MLP) {
        throw std::runtime_error("piece_transformer Stream1 inference is not implemented in the MLP network view");
    }
    return Stream1NetworkDims{
        model.state_len,
        model.num_classes,
        model.hidden1,
        model.hidden2,
        model.residual_count,
        model.output_dim,
        model.dtype,
        model.normalization};
}

inline std::vector<const half*> const_pointer_vector(const std::vector<half*>& ptrs) {
    return std::vector<const half*>(ptrs.begin(), ptrs.end());
}
inline Stream1TransformerDims transformer_dims(const Stream1ModelConfig& model) {
    if (model.backend != STREAM1_BACKEND_PIECE_TRANSFORMER) {
        throw std::runtime_error("MLP Stream1 model cannot be viewed as a piece_transformer");
    }
    const auto sequence = transformer_sequence_plan(model);
    return Stream1TransformerDims{
        model.state_len,
        model.num_classes,
        model.num_pieces,
        model.max_piece_size,
        sequence.logical_seq_len,
        sequence.padded_seq_len,
        sequence.alignment,
        model.d_model,
        model.nhead,
        model.head_dim,
        model.transformer_layers,
        model.ff_dim,
        model.output_dim,
        model.dtype,
        model.activation};
}

struct TransformerNetworkViewHolder {
    std::vector<Stream1TransformerBlockView> blocks;
    Stream1TransformerNetworkView view{};
};

inline TransformerNetworkViewHolder transformer_network_view(
    const DeviceTransformerWeights& weights,
    const Stream1ModelConfig& model) {
    if (model.backend != STREAM1_BACKEND_PIECE_TRANSFORMER) {
        throw std::runtime_error("MLP Stream1 weights cannot be viewed as a piece_transformer");
    }
    if (weights.blocks.size() != model.transformer_layers) {
        throw std::runtime_error("device transformer block count does not match manifest");
    }
    TransformerNetworkViewHolder holder;
    holder.blocks.resize(weights.blocks.size());
    for (std::size_t i = 0; i < weights.blocks.size(); ++i) {
        const DeviceTransformerBlockWeights& b = weights.blocks[i];
        holder.blocks[i] = Stream1TransformerBlockView{
            b.ln1_gamma,
            b.ln1_beta,
            b.attn_qkv_weight,
            b.attn_qkv_bias,
            b.attn_out_weight,
            b.attn_out_bias,
            b.ln2_gamma,
            b.ln2_beta,
            b.ff1_weight,
            b.ff1_bias,
            b.ff2_weight,
            b.ff2_bias,
            b.qkv_e4m3_scale,
            b.ff1_e4m3_scale,
            b.ff2_e4m3_scale,
            b.ff2_hopper_fp16,
            b.qkv_hopper_fp16,
            b.ff1_hopper_fp16};
    }
    holder.view = Stream1TransformerNetworkView{
        weights.fast_slot_projected,
        weights.fast_piece_static,
        weights.cls_token,
        weights.input_ln_gamma,
        weights.input_ln_beta,
        weights.output_ln_gamma,
        weights.output_ln_beta,
        holder.blocks.data(),
        weights.output_weight,
        weights.output_bias,
        weights.piece_positions,
        weights.piece_mask,
        weights.piece_types,
        transformer_dims(model)};
    return holder;
}

inline void free_transformer_network_view(TransformerNetworkViewHolder& holder) {
    holder = TransformerNetworkViewHolder{};
}

inline Stream1CutlassScratch mlp_scratch_view(
    const ScratchAllocation& scratch,
    const Stream1ModelConfig& model,
    std::uint32_t b_micro,
    std::uint32_t lane) {
    if (model.backend != STREAM1_BACKEND_MLP) {
        throw std::runtime_error("piece_transformer Stream1 scratch cannot be viewed as MLP scratch");
    }
    const std::uint64_t rows = stream1_inference_rows(b_micro, model);
    const std::uint64_t lane_rows = static_cast<std::uint64_t>(lane) * rows;
    return Stream1CutlassScratch{
        scratch.hidden1 + lane_rows * model.hidden1,
        scratch.hidden2 + lane_rows * model.hidden2,
        scratch.residual + lane_rows * model.hidden2,
        scratch.output + lane_rows * model.output_dim};
}

inline Stream1TransformerScratchView transformer_scratch_view(const ScratchAllocation& scratch) {
    return Stream1TransformerScratchView{
        scratch.transformer_tokens,
        scratch.transformer_qkv,
        scratch.transformer_attention_scores_probs,
        scratch.transformer_attention_context,
        scratch.transformer_ff_hidden,
        scratch.transformer_logits,
        scratch.transformer_numeric_error};
}

inline Stream1TransformerScratchView transformer_scratch_view(
    const ScratchAllocation& scratch,
    const Stream1ModelConfig& model,
    std::uint32_t b_micro,
    std::uint32_t lane) {
    if (model.backend != STREAM1_BACKEND_PIECE_TRANSFORMER) {
        throw std::runtime_error("MLP Stream1 scratch cannot be viewed as a piece_transformer");
    }
    const auto sequence = transformer_sequence_plan(model);
    const std::uint64_t rows = stream1_inference_rows(b_micro, model);
    const std::uint64_t lane_rows = static_cast<std::uint64_t>(lane) * rows;
    return Stream1TransformerScratchView{
        scratch.transformer_tokens + lane_rows * sequence.padded_seq_len * model.d_model,
        scratch.transformer_qkv + lane_rows * sequence.padded_seq_len * 3ULL * model.d_model,
        scratch.transformer_attention_scores_probs + lane_rows * model.nhead * transformer_attention_score_stride(model),
        scratch.transformer_attention_context + lane_rows * sequence.padded_seq_len * model.d_model,
        scratch.transformer_ff_hidden + lane_rows * sequence.padded_seq_len * model.ff_dim,
        scratch.transformer_logits + lane_rows * model.output_dim,
        scratch.transformer_numeric_error};
}
#endif

} // namespace beam::stream1_weights
