#include "config.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace beam {

bool stream1_uses_child_rows(const Stream1ModelConfig& model) {
    switch (model.backend) {
    case STREAM1_BACKEND_MLP:
        return model.output_dim == STREAM1_SINGLE_SCORE_OUTPUT_DIM;
    case STREAM1_BACKEND_PIECE_TRANSFORMER:
        return false;
    default:
        throw std::invalid_argument("unsupported Stream1 backend");
    }
}

std::uint32_t stream1_rows_per_parent(const Stream1ModelConfig& model) {
    return stream1_uses_child_rows(model) ? static_cast<std::uint32_t>(MOVE_COUNT) : 1U;
}

std::uint32_t stream1_parent_batch_from_row_budget(std::uint32_t row_budget, const Stream1ModelConfig& model) {
    const std::uint32_t rows_per_parent = stream1_rows_per_parent(model);
    if (row_budget < rows_per_parent) {
        throw std::invalid_argument("BEAM_B_MICRO row budget is smaller than one Stream1 parent expansion");
    }
    return row_budget / rows_per_parent;
}

std::uint64_t stream1_inference_rows(std::uint32_t parent_batch, const Stream1ModelConfig& model) {
    return static_cast<std::uint64_t>(parent_batch) * stream1_rows_per_parent(model);
}

std::uint64_t round_up(std::uint64_t value, std::uint64_t alignment) {
    if (alignment == 0) {
        return value;
    }
    const std::uint64_t remainder = value % alignment;
    const std::uint64_t increment = remainder == 0 ? 0 : alignment - remainder;
    if (increment > std::numeric_limits<std::uint64_t>::max() - value) {
        throw std::overflow_error("aligned size exceeds uint64 capacity");
    }
    return value + increment;
}

DerivedConfig derive_config(const RuntimeConfig& config) {
    DerivedConfig derived;
    const std::uint64_t candidates_wide = static_cast<std::uint64_t>(config.b_micro) * MOVE_COUNT;
    if (candidates_wide > std::numeric_limits<std::uint32_t>::max()) {
        throw std::overflow_error("B_MICRO * MOVE_COUNT exceeds uint32 capacity");
    }
    const auto candidates_per_slot = static_cast<std::uint32_t>(candidates_wide);
    if (candidates_per_slot == 0U || config.stream3_batch_candidates % candidates_per_slot != 0U) {
        throw std::invalid_argument("STREAM3_BATCH_CANDIDATES must be divisible by B_MICRO * MOVE_COUNT");
    }
    derived.ring_slot_count = config.stream3_batch_candidates / candidates_per_slot;
    if (config.inference_parallelism == 0U ||
        config.inference_parallelism > derived.ring_slot_count) {
        throw std::invalid_argument("STREAM1_CONCURRENCY must be in [1, RING_SLOT_COUNT]");
    }
    const std::uint64_t shard_domains =
        static_cast<std::uint64_t>(config.world_size) * config.shard_count;
    if (config.stream4_batch_alignment != 0 &&
        shard_domains > std::numeric_limits<std::uint64_t>::max() / config.stream4_batch_alignment) {
        throw std::overflow_error("beam width alignment exceeds uint64 capacity");
    }
    derived.beam_width_alignment = shard_domains * config.stream4_batch_alignment;
    derived.global_beam_width_effective = round_up(config.user_global_beam_width, derived.beam_width_alignment);
    return derived;
}

std::uint32_t q_to_score_key(float q) {
    const float clamped = std::min(std::max(q, 0.0f), SCORE_MAX_Q);
    return static_cast<std::uint32_t>(std::lround(clamped * static_cast<float>(SCORE_SCALE)));
}

} // namespace beam
