# Per Stream Benchmark 2026-05-22

- puzzle_id=2
- gpu_total_bytes=150109880320
- gpu_free_before_bytes=149556166656
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=0
- weight_dir=/workspace/stream1_transformer_weights_fp16
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=6371424
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=384
- filter_concurrency=8

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|384|8|3072|5.2887|580858.3|13940599.1|371933184|216.040|437234688|1819606238498038659|`3936,2004,4190,4207,4155,4323,4342,4114,4076,4085,4106,4113,4138,4076,4126,4091,4072,4234,4176,4152,4161,4167,4110,4219`|1109016576|89653248|268959744|301989888|89653248|358612992|147456|

## Status

- status=pass
