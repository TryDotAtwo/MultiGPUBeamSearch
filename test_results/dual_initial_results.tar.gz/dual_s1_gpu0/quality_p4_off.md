# Per Stream Benchmark 2026-05-22

- puzzle_id=4
- gpu_total_bytes=150109880320
- gpu_free_before_bytes=149556166656
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=0
- weight_dir=/workspace/stream1_transformer_weights_fp16
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=6371424
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=384
- filter_concurrency=8

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|384|8|3072|5.5783|550704.0|13216896.0|371933184|204.825|643867648|13021304547667456899|`6398,6438,6394,6501,6243,6471,6578,6354,6484,6427,4364,6393,6388,6278,6390,6435,6504,6536,6424,5908,6505,6391,6546,6545`|1109016576|89653248|268959744|301989888|89653248|358612992|147456|

## Status

- status=pass
