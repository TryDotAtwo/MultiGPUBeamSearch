# Per Stream Benchmark 2026-05-22

- puzzle_id=8
- gpu_total_bytes=150109880320
- gpu_free_before_bytes=149556166656
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=0
- weight_dir=/workspace/stream1_transformer_weights_fp16
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=6371424
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=384
- filter_concurrency=8

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|384|8|3072|5.2878|580963.8|13943130.9|371933184|216.080|747637760|8567052522601536387|`8630,8358,8594,8749,8391,8595,8386,8562,8516,8479,8700,8677,8564,8646,8526,8407,8600,8696,8528,6444,8461,8587,8550,8557`|1109016576|89653248|268959744|301989888|89653248|358612992|147456|

## Status

- status=pass
