# Per Stream Benchmark 2026-05-22

- puzzle_id=6
- gpu_total_bytes=150109880320
- gpu_free_before_bytes=149557411840
- generator_path=FullBeamNice/generators/p900.json
- puzzle_info_path=data/puzzle_info.json
- test_csv_path=data/test.csv
- synthetic_states=0
- weight_dir=/workspace
- stream1_model_hidden1=1536
- stream1_model_hidden2=512
- stream1_model_residual_count=2
- stream1_model_output_dim=24
- stream1_model_weight_bytes=6371424
- cuda_architectures=75,86
- stream1_gemm=TensorOp_runtime_arch_dispatch_sm80_or_sm75
- stream1_backend=piece_transformer

## Stream1 Piece Transformer

- graph_bench=1
- filter_b_micro=384
- filter_concurrency=8

| b_micro | concurrency | rows_per_launch_group | ms_per_launch_group | parents_per_sec | candidates_per_sec | estimated_flops_per_parent | achieved_tflops | checksum | score_key_digest | first_score_keys | scratch_bytes | token_bytes | qkv_bytes | attention_bytes | context_bytes | ff_hidden_bytes | logits_bytes |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|
|384|8|3072|5.0806|604657.1|14511770.5|371933184|224.892|807314432|14428844108605625219|`8614,8538,8586,8009,7515,8259,8742,8538,8644,8623,8196,8273,8336,8422,8582,8411,6840,8552,7596,8956,8989,8779,8518,8405`|1109016576|89653248|268959744|301989888|89653248|358612992|147456|

## Status

- status=pass
